"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { createApp } = require("../server/app");

let server, base, dataDir, ctx;

function startServer(opts) {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "qrh-test-"));
  ctx = createApp({ dataDir, secureCookie: false, ...opts });
  return new Promise((resolve) => {
    server = ctx.app.listen(0, "127.0.0.1", () => {
      base = "http://127.0.0.1:" + server.address().port;
      resolve();
    });
  });
}
function stopServer() {
  return new Promise((resolve) => server.close(() => { ctx.close(); fs.rmSync(dataDir, { recursive: true, force: true }); resolve(); }));
}

// Tiny client with its own cookie jar.
function client() {
  let cookie = "";
  async function call(method, url, body, extraHeaders = {}, raw) {
    const headers = { "x-qrh-client": "1", ...extraHeaders };
    if (cookie) headers.cookie = cookie;
    let payload;
    if (raw !== undefined) {
      payload = raw;
      headers["content-type"] = headers["content-type"] || "application/pdf";
    } else if (body !== undefined) {
      payload = JSON.stringify(body);
      headers["content-type"] = "application/json";
    }
    const res = await fetch(base + url, { method, headers, body: payload });
    const set = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    set.forEach((c) => {
      const pair = c.split(";")[0];
      if (pair.endsWith("=")) cookie = "";
      else cookie = pair;
    });
    const text = await res.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch (e) { /* binary or empty */ }
    return { status: res.status, json, text, headers: res.headers, setCookie: set };
  }
  return { call, get cookie() { return cookie; }, set cookie(v) { cookie = v; } };
}

const PW = "correct horse battery";
const PDF = Buffer.from("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n");

before(() => startServer({ authLimitPerIp: 1000, authLimitPerEmail: 1000 }));
after(() => stopServer());

test("signup validates input and sets a hardened session cookie", async () => {
  const c = client();
  assert.equal((await c.call("POST", "/api/auth/signup", { email: "nope", password: PW })).status, 400);
  assert.equal((await c.call("POST", "/api/auth/signup", { email: "a@example.com", password: "short" })).status, 400);
  assert.equal((await c.call("POST", "/api/auth/signup", { email: "a@example.com", password: "x".repeat(73) })).status, 400);
  assert.equal((await c.call("POST", "/api/auth/signup", { email: 5, password: PW })).status, 400);
  const r = await c.call("POST", "/api/auth/signup", { email: "Pilot@Example.com", password: PW });
  assert.equal(r.status, 201);
  assert.equal(r.json.user.email, "pilot@example.com");
  const sc = r.setCookie.join(";").toLowerCase();
  assert.match(sc, /httponly/);
  assert.match(sc, /samesite=lax/);
  const me = await c.call("GET", "/api/auth/me");
  assert.equal(me.status, 200);
  assert.equal(me.json.user.email, "pilot@example.com");
});

test("duplicate signup is rejected, case-insensitively", async () => {
  const c = client();
  const r = await c.call("POST", "/api/auth/signup", { email: "PILOT@example.com", password: PW });
  assert.equal(r.status, 409);
});

test("passwords are stored as bcrypt hashes, never plaintext", () => {
  const row = ctx.db.prepare("SELECT pass_hash FROM users WHERE email = ?").get("pilot@example.com");
  assert.match(row.pass_hash, /^\$2[aby]\$12\$/);
  assert.ok(!row.pass_hash.includes(PW));
});

test("session tokens are stored hashed", async () => {
  const c = client();
  await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  const token = c.cookie.split("=")[1];
  const rows = ctx.db.prepare("SELECT token_hash FROM sessions").all();
  assert.ok(rows.length >= 1);
  assert.ok(rows.every((r) => r.token_hash !== token && r.token_hash.length === 64));
});

test("login failure message does not reveal whether the email exists", async () => {
  const c = client();
  const a = await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: "wrong password here" });
  const b = await c.call("POST", "/api/auth/login", { email: "ghost@example.com", password: "wrong password here" });
  assert.equal(a.status, 401);
  assert.equal(b.status, 401);
  assert.deepEqual(a.json, b.json);
});

test("state-changing requests without the client header are refused", async () => {
  const c = client();
  const res = await fetch(base + "/api/auth/login", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: "pilot@example.com", password: PW }),
  });
  assert.equal(res.status, 403);
});

test("protected routes need a valid session", async () => {
  const c = client();
  assert.equal((await c.call("GET", "/api/docs")).status, 401);
  assert.equal((await c.call("GET", "/api/files?aircraft=x")).status, 401);
  c.cookie = "qrh_sid=forged-token-value";
  assert.equal((await c.call("GET", "/api/docs")).status, 401);
  assert.equal((await c.call("GET", "/api/auth/me")).status, 401);
});

test("docs: create, read, version conflict, validation, size limit", async () => {
  const c = client();
  await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  const key = "ac:Piper|PA-34-220T Seneca III";

  let r = await c.call("PUT", "/api/docs", { key, value: { speeds: { vyse: "90" }, procs: {} }, baseVersion: 0, updatedAt: 1000 });
  assert.equal(r.status, 200);
  assert.equal(r.json.version, 1);

  r = await c.call("PUT", "/api/docs", { key, value: { speeds: { vyse: "91" }, procs: {} }, baseVersion: 1, updatedAt: 2000 });
  assert.equal(r.status, 200);
  assert.equal(r.json.version, 2);

  // stale base version -> conflict, server copy returned
  r = await c.call("PUT", "/api/docs", { key, value: { speeds: { vyse: "99" }, procs: {} }, baseVersion: 1, updatedAt: 3000 });
  assert.equal(r.status, 409);
  assert.equal(r.json.current.version, 2);
  assert.equal(r.json.current.value.speeds.vyse, "91");

  r = await c.call("GET", "/api/docs");
  assert.equal(r.status, 200);
  const d = r.json.docs.find((x) => x.key === key);
  assert.equal(d.value.speeds.vyse, "91");
  assert.equal(d.version, 2);

  assert.equal((await c.call("PUT", "/api/docs", { key: "", value: 1, baseVersion: 0 })).status, 400);
  assert.equal((await c.call("PUT", "/api/docs", { key: "a\u0000b", value: 1, baseVersion: 0 })).status, 400);
  assert.equal((await c.call("PUT", "/api/docs", { key: "k", baseVersion: 0 })).status, 400);
  assert.equal((await c.call("PUT", "/api/docs", { key: "k", value: 1, baseVersion: -1 })).status, 400);
  assert.equal((await c.call("PUT", "/api/docs", { key: "k", value: 1, baseVersion: "0" })).status, 400);

  const big = await c.call("PUT", "/api/docs", { key: "big", value: "x".repeat(650 * 1024), baseVersion: 0 });
  assert.ok(big.status === 413 || big.status === 400, "oversized doc refused, got " + big.status);

  // future timestamps are clamped
  r = await c.call("PUT", "/api/docs", { key: "clamp", value: 1, baseVersion: 0, updatedAt: Date.now() + 10 * 86400000 });
  assert.equal(r.status, 200);
  assert.ok(r.json.updatedAt <= Date.now() + 6 * 60 * 1000);
});

test("accounts cannot see or overwrite each other's docs or files", async () => {
  const a = client();
  const b = client();
  await a.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  assert.equal((await b.call("POST", "/api/auth/signup", { email: "other@example.com", password: PW })).status, 201);

  await a.call("PUT", "/api/docs", { key: "secret", value: { n: 1 }, baseVersion: 0 });
  const bDocs = await b.call("GET", "/api/docs");
  assert.ok(!bDocs.json.docs.some((d) => d.key === "secret"));
  // B writing the same key creates B's own row, never touches A's
  const w = await b.call("PUT", "/api/docs", { key: "secret", value: { n: 2 }, baseVersion: 0 });
  assert.equal(w.status, 200);
  const aDocs = await a.call("GET", "/api/docs");
  assert.equal(aDocs.json.docs.find((d) => d.key === "secret").value.n, 1);

  const up = await a.call("POST", "/api/files?aircraft=Cessna%7C172S&name=mine.pdf", undefined, {}, PDF);
  assert.equal(up.status, 201);
  const id = up.json.file.id;
  assert.equal((await b.call("GET", "/api/files/" + id)).status, 404);
  assert.equal((await b.call("DELETE", "/api/files/" + id)).status, 404);
  assert.equal((await a.call("GET", "/api/files/" + id)).status, 200);
});

test("files: only real PDFs, safe names, correct headers, no path traversal", async () => {
  const c = client();
  await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  const key = encodeURIComponent("Cessna|152");

  assert.equal((await c.call("POST", "/api/files?aircraft=" + key, undefined, {}, Buffer.from("not a pdf at all"))).status, 400);
  assert.equal((await c.call("POST", "/api/files?aircraft=" + key, undefined, {}, Buffer.alloc(0))).status, 400);
  assert.equal((await c.call("POST", "/api/files?name=x.pdf", undefined, {}, PDF)).status, 400);
  const wrongType = await c.call("POST", "/api/files?aircraft=" + key, undefined, { "content-type": "text/html" }, Buffer.from("<script>alert(1)</script>"));
  assert.ok([400, 415].includes(wrongType.status) || wrongType.status === 400, "non-pdf content type refused: " + wrongType.status);

  const up = await c.call("POST", "/api/files?aircraft=" + key + "&name=" + encodeURIComponent("../../etc/passwd<>.txt"), undefined, {}, PDF);
  assert.equal(up.status, 201);
  assert.ok(!/[\\/<>]/.test(up.json.file.name), "name sanitised: " + up.json.file.name);
  assert.match(up.json.file.name, /\.pdf$/);

  const dl = await c.call("GET", "/api/files/" + up.json.file.id);
  assert.equal(dl.status, 200);
  assert.equal(dl.headers.get("content-type"), "application/pdf");
  assert.equal(dl.headers.get("x-content-type-options"), "nosniff");
  assert.match(dl.headers.get("cache-control"), /no-store/);
  assert.ok(dl.text.startsWith("%PDF-"));

  for (const bad of ["..%2F..%2Fetc%2Fpasswd", "%2e%2e%2f%2e%2e%2fetc%2fpasswd", "../../server/db.js", "zzzz", "A".repeat(32)]) {
    const r = await c.call("GET", "/api/files/" + bad);
    assert.ok(r.status === 404 || r.status === 400, bad + " -> " + r.status);
  }

  const list = await c.call("GET", "/api/files?aircraft=" + key);
  assert.equal(list.json.files.length, 1);
  assert.equal((await c.call("DELETE", "/api/files/" + up.json.file.id)).status, 200);
  assert.equal((await c.call("GET", "/api/files/" + up.json.file.id)).status, 404);
  const onDisk = fs.readdirSync(path.join(dataDir, "files"));
  await new Promise((r) => setTimeout(r, 50));
  assert.ok(!fs.readdirSync(path.join(dataDir, "files")).includes(up.json.file.id + ".pdf"), "file removed from disk " + onDisk.length);
});

test("files over 25 MB are refused", async () => {
  const c = client();
  await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  const big = Buffer.concat([Buffer.from("%PDF-1.4\n"), Buffer.alloc(26 * 1024 * 1024, 1)]);
  const r = await c.call("POST", "/api/files?aircraft=x&name=big.pdf", undefined, {}, big);
  assert.equal(r.status, 413);
});

test("security headers are present", async () => {
  const res = await fetch(base + "/index.html");
  assert.equal(res.status, 200);
  const csp = res.headers.get("content-security-policy");
  assert.ok(csp && csp.includes("script-src 'self'") && !/script-src[^;]*unsafe-inline/.test(csp), csp);
  assert.ok(csp.includes("frame-ancestors 'none'"));
  assert.equal(res.headers.get("x-content-type-options"), "nosniff");
  assert.equal(res.headers.get("x-powered-by"), null);
  const api = await fetch(base + "/api/auth/me");
  assert.match(api.headers.get("cache-control"), /no-store/);
  const sw = await fetch(base + "/sw.js");
  assert.match(sw.headers.get("cache-control"), /no-cache/);
});

test("malformed JSON gets a clean 400 with no stack trace", async () => {
  const res = await fetch(base + "/api/auth/login", {
    method: "POST",
    headers: { "content-type": "application/json", "x-qrh-client": "1" },
    body: "{not json",
  });
  assert.equal(res.status, 400);
  const t = await res.text();
  assert.ok(!t.includes("node_modules") && !t.includes(" at "));
});

test("logout invalidates the session on the server", async () => {
  const c = client();
  await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  const stolen = c.cookie;
  assert.equal((await c.call("GET", "/api/auth/me")).status, 200);
  await c.call("POST", "/api/auth/logout", {});
  const replay = client();
  replay.cookie = stolen;
  assert.equal((await replay.call("GET", "/api/auth/me")).status, 401);
});

test("expired sessions are rejected", async () => {
  const c = client();
  await c.call("POST", "/api/auth/login", { email: "pilot@example.com", password: PW });
  ctx.db.prepare("UPDATE sessions SET expires_at = ?").run(Date.now() - 1000);
  assert.equal((await c.call("GET", "/api/auth/me")).status, 401);
});

test("account deletion needs the password and removes data and files", async () => {
  const c = client();
  assert.equal((await c.call("POST", "/api/auth/login", { email: "other@example.com", password: PW })).status, 200);
  const up = await c.call("POST", "/api/files?aircraft=gone&name=g.pdf", undefined, {}, PDF);
  assert.equal(up.status, 201);
  const id = up.json.file.id;
  assert.ok(fs.existsSync(path.join(dataDir, "files", id + ".pdf")));

  assert.equal((await c.call("POST", "/api/auth/delete", { password: "wrong password!!" })).status, 401);
  assert.equal((await c.call("POST", "/api/auth/delete", { password: PW })).status, 200);
  await new Promise((r) => setTimeout(r, 80));

  assert.ok(!fs.existsSync(path.join(dataDir, "files", id + ".pdf")), "pdf removed");
  assert.equal(ctx.db.prepare("SELECT COUNT(*) n FROM users WHERE email = 'other@example.com'").get().n, 0);
  assert.equal(ctx.db.prepare("SELECT COUNT(*) n FROM docs WHERE key = 'secret' AND user_id NOT IN (SELECT id FROM users)").get().n, 0);
  assert.equal((await c.call("POST", "/api/auth/login", { email: "other@example.com", password: PW })).status, 401);
});

test("unknown API routes return JSON 404", async () => {
  const r = await fetch(base + "/api/nope");
  assert.equal(r.status, 404);
  assert.deepEqual(await r.json(), { error: "Not found." });
});

test("login is rate limited per account", async () => {
  await stopServer();
  await startServer({ authLimitPerIp: 1000, authLimitPerEmail: 5 });
  const c = client();
  await c.call("POST", "/api/auth/signup", { email: "rate@example.com", password: PW });
  const codes = [];
  for (let i = 0; i < 9; i++) {
    codes.push((await c.call("POST", "/api/auth/login", { email: "rate@example.com", password: "bad password here" })).status);
  }
  assert.ok(codes.includes(429), "expected a 429 in " + codes.join(","));
  assert.equal(codes[0], 401);
});

test("signup is rate limited per IP", async () => {
  await stopServer();
  await startServer({ authLimitPerIp: 4, authLimitPerEmail: 1000 });
  const c = client();
  const codes = [];
  for (let i = 0; i < 7; i++) {
    codes.push((await c.call("POST", "/api/auth/signup", { email: "u" + i + "@example.com", password: PW })).status);
  }
  assert.ok(codes.includes(429), "expected a 429 in " + codes.join(","));
});
