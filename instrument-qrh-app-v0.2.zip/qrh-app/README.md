# Instrument QRH

Quick reference handbook for instrument students and IFR currency. It is an installable offline web app (PWA) with an optional account system. Pilots can use it with no account. Signing in syncs their aircraft notes, weight and balance data, favorites and uploaded POH PDFs across devices. Everything a pilot enters is private to their account.

The server is Node 20+ with Express 5 and SQLite (better-sqlite3). The frontend is plain HTML, CSS and JavaScript in `public/`, with no build step.

## Run it locally

```
npm install
npm start
```

Open http://localhost:8000. Data is written to `./data` (SQLite file plus uploaded PDFs).

## Tests

```
npm test
```

Runs the API suite: auth hardening, hashed passwords and session tokens, CSRF header, document versioning and conflicts, per-user isolation, PDF validation and size limits, security headers, rate limits, account deletion.

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| PORT | 8000 | Port to listen on |
| DATA_DIR | ./data | Where the database and uploaded PDFs live. Must be on a persistent disk |
| COOKIE_SECURE | on when NODE_ENV=production | Set the Secure flag on the session cookie. Needs HTTPS |
| TRUST_PROXY | off | Set to 1 when running behind one reverse proxy (Render, Fly, nginx, Caddy) so rate limits see the real client IP |
| SESSION_DAYS | 30 | Session lifetime |
| NODE_ENV | | Use `production` when deployed |

## Deploy

Accounts need two things: HTTPS (the session cookie is Secure) and a persistent disk mounted at DATA_DIR. A host with only ephemeral storage will lose every account on restart.

With Docker:

```
docker build -t instrument-qrh .
docker run -p 8000:8000 -v qrh-data:/data \
  -e NODE_ENV=production -e TRUST_PROXY=1 instrument-qrh
```

Put it behind a reverse proxy or a host that terminates HTTPS (Fly.io, Render, Railway, a VPS with Caddy). Check `/healthz` for a liveness probe.

Back up DATA_DIR regularly. For a consistent copy of the database while running, use `sqlite3 data/qrh.db ".backup backup.db"` and copy the `files/` folder alongside it.

## Password resets

There is no email reset flow yet. As the owner you can reset a password from the server:

```
DATA_DIR=/data node scripts/reset-password.js pilot@example.com "new password here"
```

This also signs the account out everywhere.

## Releasing a frontend change

The service worker serves cached files first. After changing anything in `public/`, bump `CACHE_VERSION` in `public/sw.js`. Installed copies pick up the new version the next time they open the app online.

## Safety and content notes

- Aircraft-specific emergency steps, speeds, empty weights, arms and CG envelopes are deliberately not pre-filled. Pilots enter them from their own POH/AFM, and the app says so on screen.
- Uploaded POH PDFs are stored privately per account and are never shown to other pilots, so the app does not redistribute manufacturer content.
- Check the regulatory content (FAR 61.57, 61.56, AIM references) against current publications before each release.

## Layout

| Path | Purpose |
| --- | --- |
| public/ | The app: index.html, app.js, sync.js, styles.css, sw.js, manifest, icons |
| server/ | app.js (wiring and security headers), auth.js, docs.js, files.js, db.js, index.js |
| scripts/reset-password.js | Owner password reset |
| test/ | API tests |
