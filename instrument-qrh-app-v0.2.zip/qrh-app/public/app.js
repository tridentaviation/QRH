/* =========================================================================
   DATA
   ========================================================================= */
const SECTIONS = [
  { id: "preflight", label: "Preflight & Planning", short: "Preflight", color: "#52D6EC" },
  { id: "departure", label: "Clearance & Departure", short: "Departure", color: "#34D399" },
  { id: "enroute",   label: "Enroute & Holding", short: "Enroute", color: "#F5A524" },
  { id: "approach",  label: "Approach", short: "Approach", color: "#B295F5" },
  { id: "missed",    label: "Missed Approach & Lost Comm", short: "Missed/Lost Comm", color: "#F5636B" },
  { id: "emergency", label: "Emergency & Partial Panel", short: "Emergency", color: "#FB7DA8" },
  { id: "currency",  label: "Currency & IPC", short: "Currency", color: "#2DD4BF" },
  { id: "aircraft",  label: "Aircraft Emergency Library", short: "Aircraft", color: "#F59E6B" },
  { id: "tools",     label: "Tools", short: "Tools", color: "#8FA0B5" },
];

const CARDS = {
  preflight: [
    { title: "IM SAFE", type: "mnemonic", rows: [
      ["I","Illness \u2014 any symptoms, even minor?"],
      ["M","Medication \u2014 prescription or over-the-counter drugs taken?"],
      ["S","Stress \u2014 psychological pressure from finances, health, or family?"],
      ["A","Alcohol \u2014 none within 8 hours; stay under 0.04% BAC"],
      ["F","Fatigue \u2014 adequately rested?"],
      ["E","Emotion \u2014 emotionally upset or distracted?"],
    ]},
    { title: "PAVE", type: "mnemonic", rows: [
      ["P","Pilot \u2014 health, currency, proficiency"],
      ["A","Aircraft \u2014 airworthiness, equipment, performance"],
      ["V","EnVironment \u2014 weather, terrain, airports/runways to be used"],
      ["E","External pressures \u2014 schedules, passengers waiting, get-there-itis"],
    ]},
    { title: "DECIDE \u2014 ongoing risk management", type: "mnemonic", rows: [
      ["D","Detect a change has occurred"],
      ["E","Estimate the need to counter it"],
      ["C","Choose a desirable outcome"],
      ["I","Identify solutions"],
      ["D","Do the necessary actions"],
      ["E","Evaluate the effect of the actions"],
    ]},
    { title: "Personal documents required", type: "text", body: [
      "Pilot certificate, medical certificate (or driver's license under BasicMed/61.113), government photo ID, and a restricted radiotelephone permit for flights outside the US."
    ]},
    { title: "Aircraft documents \u2014 ARROW", type: "mnemonic", rows: [
      ["A","Airworthiness certificate"],
      ["R","Registration certificate"],
      ["R","Radio station license (international flights only)"],
      ["O","Operating limitations (POH/AFM, placards)"],
      ["W","Weight and balance data"],
    ]},
    { title: "Required inspections \u2014 AVIATES", type: "mnemonic", rows: [
      ["A","Annual inspection \u2014 every 12 calendar months"],
      ["V","VOR check \u2014 every 30 days, for IFR use"],
      ["I","100-hour inspection \u2014 if operated for hire"],
      ["A","Altimeter / pitot-static / transponder \u2014 every 24 calendar months"],
      ["T","Transponder \u2014 every 24 calendar months"],
      ["E","ELT \u2014 every 12 months, or 1 cumulative hour of use, or 50% battery life"],
      ["S","Service bulletins / ADs \u2014 as required, one-time and recurring"],
    ]},
    { title: "VOR receiver check tolerances (91.171)", type: "table",
      head: ["Method","Tolerance"], rows: [
        ["VOT","\u00b1 4\u00b0"],
        ["Certified ground checkpoint","\u00b1 4\u00b0"],
        ["Certified airborne checkpoint","\u00b1 6\u00b0"],
        ["Dual VOR cross-check","\u00b1 4\u00b0 of each other"],
        ["Airway radial over a ground landmark, 20+ NM from the VOR","\u00b1 6\u00b0"],
      ], note: "Log date, place, bearing error, and signature for every VOR check." },
    { title: "Do you need an alternate? \u2014 the 1-2-3 rule", type: "text", body: [
      "An alternate is required unless, from 1 hour before to 1 hour after your ETA, the forecast ceiling is at least 2,000 ft AGL and visibility is at least 3 SM, with a published and available approach at the destination."
    ]},
    { title: "Standard alternate minimums (91.169)", type: "table",
      head: ["Approach type","Ceiling / Visibility"], rows: [
        ["Precision approach available","600 ft / 2 SM"],
        ["Non-precision approach available","800 ft / 2 SM"],
        ["No instrument approach at the alternate","Must allow descent from the MEA, approach, and landing under VFR"],
      ], note: "Non-standard minimums are charted with a black triangle and \u201cA\u201d on NOS plates, or on the airport briefing page in Jeppesen." },
    { title: "Fuel requirements (91.167)", type: "text", body: [
      "Enough fuel to reach the first airport of intended landing, then to the alternate (if one is required), then to fly 45 minutes more at normal cruise speed."
    ]},
    { title: "Preflight information required \u2014 NW KRAFT", type: "mnemonic", rows: [
      ["N","NOTAMs"],
      ["W","Weather reports and forecasts"],
      ["K","Known ATC traffic delays"],
      ["R","Runway lengths at airports of intended use"],
      ["A","Alternatives if the flight can't be completed as planned"],
      ["F","Fuel requirements"],
      ["T","Takeoff and landing performance data"],
    ]},
  ],

  departure: [
    { title: "Copying a clearance \u2014 CRAFT", type: "mnemonic", rows: [
      ["C","Clearance limit"],
      ["R","Route"],
      ["A","Altitude (initial, and expect-further-clearance altitude if given)"],
      ["F","Frequency \u2014 departure"],
      ["T","Transponder code"],
    ], note: "Read back promptly and in full. \u201cRead back correct\u201d confirms it \u2014 acceptance doesn't by itself guarantee you can fly it as filed if equipment or performance won't allow it." },
    { title: "Clearance void times", type: "list", items: [
      "Used at airports without a functioning tower to release you for departure",
      "Be airborne before the void time, or advise ATC within 30 minutes after if you did not depart",
      "\u201cHold for release\u201d: you may not take off until released by ATC",
      "EDCT: plan to depart no earlier than 5 min before, no later than 5 min after the assigned time",
    ]},
    { title: "ODP vs. SID", type: "table",
      head: ["","ODP","SID"], rows: [
        ["Purpose","Obstacle clearance only","Obstacle clearance + reduced ATC/pilot workload"],
        ["Issued by ATC?","No \u2014 pilot's own responsibility","Yes, included in the clearance"],
        ["Charting","Textual, sometimes graphic","Always graphic"],
        ["Decline it by","N/A \u2014 not ATC-issued","\u201cNO SIDS\u201d in flight plan remarks"],
      ]},
    { title: "Standard obstacle clearance criteria (no ODP published)", type: "list", items: [
      "Cross the departure end of the runway at least 35 ft AGL",
      "Reach 400 ft AGL before the first turn",
      "Climb at least 200 ft per NM (FPNM) until reaching the minimum IFR altitude",
    ]},
    { title: "Climb gradient \u2192 target VSI", type: "text", body: [
      "fpm = (groundspeed \u00f7 60) \u00d7 required FPNM",
      "Example: 100 kt groundspeed, 300 ft/NM required \u2192 (100 \u00f7 60) \u00d7 300 \u2248 500 fpm needed."
    ], note: "If you can't meet the published gradient, don't fly the departure as charted \u2014 request an alternative before takeoff." },
    { title: "Taxi brief \u2014 ARCH", type: "mnemonic", rows: [
      ["A","Assigned / planned runway"],
      ["R","Route"],
      ["C","Crossings and hold-short instructions"],
      ["H","Hot spots and hazards \u2014 NOTAMs, closed surfaces, construction"],
    ]},
    { title: "Takeoff brief \u2014 DEPARTS", type: "mnemonic", rows: [
      ["D","Departure review \u2014 takeoff type, initial heading, first fix/course"],
      ["E","Establish expectations \u2014 flying pilot, positive transfer of controls"],
      ["P","Plan / special considerations \u2014 weather, terrain, inop equipment"],
      ["A","Alternate \u2014 takeoff alternate or return plan if needed"],
      ["R","Runway conditions and length"],
      ["T","Trouble / tactics \u2014 rejected takeoff, engine failure"],
      ["S","Speak up \u2014 questions or concerns before rolling"],
    ]},
  ],

  enroute: [
    { title: "IFR altitude structure", type: "table",
      head: ["Altitude","Definition"], rows: [
        ["MEA","Minimum En Route Altitude \u2014 lowest altitude assuring both navigation signal and obstacle clearance between fixes"],
        ["MOCA","Minimum Obstruction Clearance Altitude \u2014 obstacle clearance guaranteed, signal only within 22 NM of the VOR"],
        ["MRA","Minimum Reception Altitude \u2014 lowest altitude an intersection can be identified"],
        ["MCA","Minimum Crossing Altitude \u2014 lowest altitude to cross a fix climbing to a higher MEA"],
        ["MAA","Maximum Authorized Altitude \u2014 highest altitude with reliable signal reception"],
        ["OROCA","Off-Route Obstruction Clearance Altitude \u2014 1,000 ft buffer (non-mountainous) or 2,000 ft (mountainous); no signal guarantee"],
      ]},
    { title: "Minimum IFR altitude \u2014 no MEA/MOCA published (91.177)", type: "list", items: [
      "Mountainous terrain: 2,000 ft above the highest obstacle within 4 NM of course",
      "Non-mountainous terrain: 1,000 ft above the highest obstacle within 4 NM of course",
    ]},
    { title: "Cruising altitude, uncontrolled airspace, below 18,000' (91.179)", type: "text", body: [
      "Magnetic course 000\u2013179\u00b0: odd thousands. Magnetic course 180\u2013359\u00b0: even thousands."
    ]},
    { title: "Mandatory reports \u2014 MARVELOUS VFR C500", type: "mnemonic", rows: [
      ["M","Missed approach"],
      ["A","Airspeed change of 10 kt or 5% of filed TAS, whichever is greater"],
      ["R","Reaching a holding fix \u2014 time and altitude"],
      ["V","VFR-on-top altitude change"],
      ["E","ETA change of 2 minutes or more (3 min North Atlantic)"],
      ["L","Leaving a holding fix or point"],
      ["O","Outer marker inbound (non-radar environments only)"],
      ["U","Un-forecast weather"],
      ["S","Safety of flight \u2014 anything relevant"],
      ["V","Vacating an assigned altitude or flight level"],
      ["F","Final approach fix inbound (non-radar environments only)"],
      ["R","Radio / nav / approach equipment failure"],
      ["C","Compulsory reporting points"],
      ["500","Unable to climb or descend at least 500 fpm"],
    ]},
    { title: "Non-radar position report \u2014 A PTA TEN R", type: "mnemonic", rows: [
      ["A","Aircraft ID"],
      ["P","Position"],
      ["T","Time"],
      ["A","Altitude"],
      ["TEN","Type of flight plan, ETA and name of next fix"],
      ["R","Remarks, plus the name of the next succeeding fix"],
    ]},
    { title: "Holding entry selection", type: "table",
      head: ["Sector","Entry"], rows: [
        ["Direct","Fly directly to the fix, then turn to follow the pattern"],
        ["Teardrop","Cross the fix, turn 30\u00b0 outbound into the protected side for 1 minute, then turn to intercept inbound"],
        ["Parallel","Cross the fix, fly the outbound heading on the non-holding side for 1 minute, then turn through the pattern to rejoin inbound"],
      ]},
    { title: "Holding timing & wind correction", type: "list", items: [
      "Standard pattern turns are to the right, at 3\u00b0/sec or 30\u00b0 bank, whichever is less",
      "Start outbound timing abeam the fix, or at wings-level if abeam can't be determined",
      "Target inbound leg: 1 minute at/below 14,000' MSL, 1.5 minutes above",
      "Wind correction: triple the inbound correction angle and apply it outbound",
    ]},
    { title: "5 T's \u2014 at the fix and every turn", type: "mnemonic", rows: [
      ["T","Turn"], ["T","Time"], ["T","Twist"], ["T","Throttle"], ["T","Talk"],
    ]},
    { title: "Maximum holding airspeeds", type: "table",
      head: ["Altitude","Max speed"], rows: [
        ["6,000' MSL and below","200 KIAS"],
        ["6,001' \u2013 14,000' MSL","230 KIAS"],
        ["14,001' MSL and above","265 KIAS"],
      ]},
  ],

  approach: [
    { title: "Aircraft approach category \u2014 1.3 x Vso (or Vref)", type: "table",
      head: ["Category","Speed range"], rows: [
        ["A","Under 91 kt"], ["B","91\u2013120 kt"], ["C","121\u2013140 kt"],
        ["D","141\u2013165 kt"], ["E","166 kt and above"],
      ], note: "Flying faster than your category's normal speed bumps you to the next category's minimums \u2014 never use a slower category's minimums than your aircraft is certified for." },
    { title: "Approach types", type: "table",
      head: ["Type","Guidance"], rows: [
        ["Precision (ILS, GLS)","Lateral and vertical guidance to a Decision Altitude (DA)"],
        ["APV (LPV, LNAV/VNAV)","Lateral and vertical guidance, doesn't meet full precision standards, flown to a DA"],
        ["Non-precision (VOR, LOC, LNAV, NDB)","Lateral guidance only, flown to a Minimum Descent Altitude (MDA)"],
      ]},
    { title: "Procedure turn NOT required \u2014 SHARP TT", type: "mnemonic", rows: [
      ["S","Straight-in approach clearance issued"],
      ["H","Holding in lieu of a procedure turn"],
      ["A","DME Arc transition"],
      ["R","Radar vectors to final"],
      ["P","No PT depicted on the chart"],
      ["T","Timed approach from a holding fix"],
      ["T","Teardrop course reversal already flown"],
    ]},
    { title: "Conditions to descend below MDA or DA (91.175)", type: "list", items: [
      "Continuously in a position to land on the intended runway using normal maneuvers and a normal descent rate",
      "Flight visibility not less than the visibility published for the approach",
      "At least one required visual reference distinctly visible: threshold, threshold markings/lights, REILs, VASI/PAPI, touchdown zone or its markings/lights, runway or its markings/lights, or the approach lights (no lower than 100 ft above TDZE on approach lights alone, unless red terminating or side-row bars are also visible)",
    ]},
    { title: "Rate of descent for a 3\u00b0 glidepath", type: "text", body: [
      "VS (fpm) = groundspeed \u00d7 5",
      "Example: 120 kt groundspeed \u2192 120 \u00d7 5 = 600 fpm"
    ]},
    { title: "Visual Descent Point (VDP), when not published", type: "text", body: [
      "VDP (NM from threshold) = HAT (ft) \u00f7 300",
      "Example: HAT 600 ft \u2192 600 \u00f7 300 = 2 NM from the threshold"
    ]},
    { title: "Top-of-descent \u2014 the \u201c3-to-1\u201d rule", type: "text", body: [
      "Distance (NM) = altitude to lose (ft) \u00f7 300",
      "Example: losing 4,500 ft \u2192 4,500 \u00f7 300 = 15 NM before the point where level altitude is needed"
    ]},
    { title: "Standard rate turn \u2014 bank angle", type: "text", body: [
      "Bank angle (\u00b0) \u2248 (TAS \u00f7 10) + 5",
      "Example: 120 KTAS \u2192 (120 \u00f7 10) + 5 = 17\u00b0 of bank for a 3\u00b0/sec turn"
    ]},
  ],

  missed: [
    { title: "Execute a missed approach when", type: "list", items: [
      "You reach the MAP (time, DME, DA, or fix) without the required visual references",
      "Required visibility or visual references are lost below MDA or DA",
      "A safe landing is no longer possible for any reason",
      "ATC instructs a go-around",
      "During a circling approach, you lose sight of the runway environment \u2014 make an initial climbing turn toward the landing runway, then join the missed approach course",
    ]},
    { title: "Missed approach flow", type: "list", items: [
      "Apply full power and establish a climb attitude",
      "Retract drag devices per your trained flow (flaps, gear as applicable)",
      "Follow the charted missed approach course and altitude",
      "Report the missed approach to ATC and state intentions",
    ], note: "A missed approach flown before reaching the MAP still follows the lateral path to the MAP before turning \u2014 obstacle clearance isn't guaranteed if you cut the corner." },
    { title: "Lost comm (91.185)", type: "text", body: [
      "Squawk 7600. If in VFR conditions, remain VFR and land as soon as practicable."
    ]},
    { title: "Lost comm route \u2014 AVE F, in priority order", type: "mnemonic", rows: [
      ["A","Assigned \u2014 the route in your last ATC clearance"],
      ["V","Vectored \u2014 direct to the fix/route/airway you were being vectored to"],
      ["E","Expected \u2014 the route ATC advised to expect in a further clearance"],
      ["F","Filed \u2014 the route in your flight plan"],
    ]},
    { title: "Lost comm altitude \u2014 fly the highest of", type: "mnemonic", rows: [
      ["M","Minimum IFR altitude for the route segment"],
      ["E","Expected \u2014 an altitude ATC advised to expect"],
      ["A","Assigned \u2014 the last altitude ATC assigned"],
    ]},
    { title: "Leaving the clearance limit", type: "list", items: [
      "Fix where an approach begins: start the approach as close as possible to the EFC time, or your filed ETA if no EFC was given",
      "Not a fix where an approach begins: leave at the EFC time (or ETA), proceed to a fix where an approach begins, then start the approach as close as possible to your filed ETA",
    ]},
  ],

  emergency: [
    { title: "Pitot-static failures", type: "table",
      head: ["Failure","Airspeed","Altimeter","VSI"], rows: [
        ["Pitot blocked, drain open","Drops to zero","Normal","Normal"],
        ["Pitot + drain both blocked","Acts like an altimeter \u2014 rises in a climb, falls in a descent","Normal","Normal"],
        ["Static port blocked","Accurate only at blockage altitude \u2014 reads low above it, high below it","Frozen at blockage altitude","Frozen at zero"],
      ], note: "Using the alternate static source (lower cabin pressure): airspeed reads slightly fast, altimeter reads slightly high, VSI shows a momentary climb." },
    { title: "Gyro / vacuum failure \u2014 partial panel", type: "text", body: [
      "Cover or ignore the failed attitude indicator and heading indicator. Fly pitch off the altimeter, VSI, and airspeed; fly bank off the turn coordinator and magnetic compass."
    ]},
    { title: "Unusual attitude \u2014 nose-high, airspeed decreasing", type: "list", items: [
      "Add power",
      "Lower the nose to prevent a stall",
      "Level the wings with coordinated aileron and rudder, by reference to the turn coordinator",
    ]},
    { title: "Unusual attitude \u2014 nose-low, airspeed increasing", type: "list", items: [
      "Reduce power to idle",
      "Level the wings first, by reference to the turn coordinator",
      "Smoothly raise the nose to level flight",
    ], note: "Trust the instruments, not your inner ear \u2014 recover by reference to airspeed, altimeter, VSI, and turn coordinator, never by feel." },
    { title: "Spatial disorientation \u2014 quick reference", type: "table",
      head: ["Illusion","What happens"], rows: [
        ["The leans","After a prolonged turn, you feel banked the opposite way once wings are level"],
        ["Graveyard spiral","In a prolonged coordinated turn you feel level; leveling the wings feels like a turn the other way, prompting back pressure that tightens the spiral"],
        ["Coriolis illusion","A head movement during a prolonged turn creates a false sense of turning or accelerating on another axis"],
        ["Somatogravic illusion","Rapid acceleration feels like pitching up; rapid deceleration feels like pitching down"],
        ["False horizon","Sloping clouds, an obscured horizon, or scattered ground lights are mistaken for the real horizon"],
        ["Autokinesis","A stationary light stared at in the dark appears to move"],
      ]},
    { title: "Coping with spatial disorientation", type: "list", items: [
      "Know the illusions and expect them",
      "Maintain instrument proficiency and stay current",
      "Avoid abrupt head movements, especially in turns and on approach",
      "Trust and fly the instruments \u2014 disregard conflicting sensory input",
    ]},
  ],

  currency: [
    { title: "Instrument currency (61.57c) \u2014 \u201c6 HITS\u201d", type: "text", body: [
      "Within the 6 calendar months before the month of flight, log: 6 instrument approaches, holding procedures and tasks, and intercepting/tracking courses using navigation systems.",
      "May be flown in actual or simulated instrument conditions, in an aircraft, FFS, FTD, or ATD representing the category of aircraft for the privileges being maintained."
    ]},
    { title: "Safety pilot requirements", type: "list", items: [
      "At least a private pilot certificate with appropriate category and class ratings",
      "Adequate vision forward and to each side of the aircraft",
      "Aircraft must have a functioning dual control system",
    ]},
    { title: "If you lapse", type: "text", body: [
      "Missed the 6-month window? You get an additional 6 months to regain currency by completing the 6 HITS with a safety pilot, instructor, or examiner under simulated instrument conditions."
    ]},
    { title: "Instrument Proficiency Check (IPC)", type: "text", body: [
      "Required once more than 6 months have passed since your instrument currency lapsed. Administered by a CFII, examiner, or other authorized evaluator, using the Instrument ACS as the standard."
    ]},
    { title: "Areas of operation an IPC must cover", type: "list", items: [
      "ATC clearances and procedures", "Flight by reference to instruments", "Navigation systems",
      "Instrument approach procedures", "Emergency operations", "Post-flight procedures",
    ], note: "Some tasks may be completed in an FTD or ATD \u2014 check the ACS for which ones." },
    { title: "Flight review (61.56)", type: "text", body: [
      "Required within the 24 calendar months before the month of flight: minimum 1 hour ground instruction and 1 hour flight instruction, given by an authorized instructor. Can be satisfied instead by a proficiency check, a practical test for a new certificate/rating, or completion of a phase of the FAA WINGS program."
    ]},
    { title: "Passenger currency (61.57a)", type: "text", body: [
      "Within the preceding 90 days: 3 takeoffs and landings in the same category, class, and type (if a type rating is required). At night \u2014 1 hour after sunset to 1 hour before sunrise \u2014 those 3 landings must be to a full stop."
    ]},
  ],
};

/* =========================================================================
   STATE
   ========================================================================= */
let state = {
  section: "preflight",
  query: "",
  favorites: new Set(),
  theme: "dark",
};

function loadLocal() {
  try {
    const f = localStorage.getItem("qrh_favorites");
    if (f) state.favorites = new Set(JSON.parse(f));
    const t = localStorage.getItem("qrh_theme");
    if (t) state.theme = t;
  } catch (e) { /* storage unavailable, continue with defaults */ }
}
function saveFavorites() {
  try { localStorage.setItem("qrh_favorites", JSON.stringify([...state.favorites])); } catch (e) {}
  if (window.qrhSync) qrhSync.markDirty();
}
function saveTheme() {
  try { localStorage.setItem("qrh_theme", state.theme); } catch (e) {}
}

function cardKey(sectionId, idx) { return sectionId + ":" + idx; }

/* =========================================================================
   RENDER: NAV
   ========================================================================= */
function renderRail() {
  const rail = document.getElementById("rail");
  rail.innerHTML = "";
  const group = document.createElement("div");
  group.className = "rail-group-label";
  group.textContent = "REFERENCE";
  rail.appendChild(group);

  SECTIONS.filter(s => s.id !== "tools").forEach(s => {
    rail.appendChild(makeRailItem(s));
  });

  const toolsLabel = document.createElement("div");
  toolsLabel.className = "rail-group-label";
  toolsLabel.textContent = "CALCULATORS";
  rail.appendChild(toolsLabel);
  rail.appendChild(makeRailItem(SECTIONS.find(s => s.id === "tools")));

  const favLabel = document.createElement("div");
  favLabel.className = "rail-group-label";
  favLabel.textContent = "SAVED";
  rail.appendChild(favLabel);
  const favItem = document.createElement("div");
  favItem.className = "rail-item" + (state.section === "favorites" ? " active" : "");
  favItem.innerHTML = `<span class="rail-dot" style="background:#F5A524"></span><span>Favorites</span><span class="rail-count">${state.favorites.size || ""}</span>`;
  favItem.onclick = () => { state.section = "favorites"; state.query=""; document.getElementById("search").value=""; renderAll(); };
  rail.appendChild(favItem);
}
function makeRailItem(s) {
  const el = document.createElement("div");
  el.className = "rail-item" + (state.section === s.id ? " active" : "");
  const count = CARDS[s.id] ? CARDS[s.id].length : "";
  el.innerHTML = `<span class="rail-dot" style="background:${s.color}"></span><span>${s.label}</span><span class="rail-count">${s.id === 'tools' ? '' : count}</span>`;
  el.onclick = () => { state.section = s.id; state.query = ""; document.getElementById("search").value = ""; renderAll(); };
  return el;
}

function renderMobileTabs() {
  const wrap = document.getElementById("mobileTabs");
  wrap.innerHTML = "";
  const all = [...SECTIONS, { id: "favorites", label: "\u2605 Favorites", color: "#F5A524" }];
  all.forEach(s => {
    const el = document.createElement("div");
    el.className = "mtab" + (state.section === s.id ? " active" : "");
    el.textContent = s.short || s.label;
    if (state.section === s.id) el.style.background = s.color;
    el.onclick = () => { state.section = s.id; state.query = ""; document.getElementById("search").value = ""; renderAll(); };
    wrap.appendChild(el);
  });
}

/* =========================================================================
   RENDER: CONTENT
   ========================================================================= */
function highlight(text, q) {
  if (!q) return text;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx === -1) return text;
  return text.slice(0, idx) + "<mark>" + text.slice(idx, idx + q.length) + "</mark>" + text.slice(idx + q.length);
}

function cardMatches(card, q) {
  if (!q) return true;
  const hay = JSON.stringify(card).toLowerCase();
  return hay.includes(q.toLowerCase());
}

function renderCard(sectionId, card, idx, color, q) {
  const key = cardKey(sectionId, idx);
  const isFav = state.favorites.has(key);
  const div = document.createElement("div");
  div.className = "card";
  div.style.setProperty("--sec-color", color);

  const titleRow = document.createElement("div");
  titleRow.className = "card-title";
  const titleSpan = document.createElement("span");
  titleSpan.innerHTML = highlight(card.title, q);
  titleRow.appendChild(titleSpan);

  const star = document.createElement("button");
  star.className = "star-btn" + (isFav ? " on" : "");
  star.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.1 8.3 22 9.3 17 14.1 18.2 21 12 17.8 5.8 21 7 14.1 2 9.3 8.9 8.3 12 2"/></svg>`;
  star.onclick = () => {
    if (state.favorites.has(key)) state.favorites.delete(key); else state.favorites.add(key);
    saveFavorites();
    renderAll();
  };
  titleRow.appendChild(star);
  div.appendChild(titleRow);

  if (card.type === "mnemonic") {
    card.rows.forEach(([l, t]) => {
      const row = document.createElement("div");
      row.className = "mnem-row";
      row.innerHTML = `<span class="mnem-letter">${l}</span><span class="mnem-text">${highlight(t, q)}</span>`;
      div.appendChild(row);
    });
  } else if (card.type === "table") {
    const table = document.createElement("table");
    table.className = "ref";
    const thead = document.createElement("thead");
    thead.innerHTML = "<tr>" + card.head.map(h => `<th>${h}</th>`).join("") + "</tr>";
    table.appendChild(thead);
    const tbody = document.createElement("tbody");
    card.rows.forEach(r => {
      const tr = document.createElement("tr");
      tr.innerHTML = r.map(c => `<td>${highlight(String(c), q)}</td>`).join("");
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    div.appendChild(table);
  } else if (card.type === "list") {
    const ul = document.createElement("ul");
    ul.className = "blist";
    card.items.forEach(it => {
      const li = document.createElement("li");
      li.innerHTML = highlight(it, q);
      ul.appendChild(li);
    });
    div.appendChild(ul);
  } else if (card.type === "text") {
    card.body.forEach(p => {
      const para = document.createElement("p");
      para.className = "plain";
      para.innerHTML = highlight(p, q);
      div.appendChild(para);
    });
  }

  if (card.note) {
    const note = document.createElement("p");
    note.className = "card-note";
    note.innerHTML = highlight(card.note, q);
    div.appendChild(note);
  }

  return div;
}

function renderMain() {
  const main = document.getElementById("main");
  main.innerHTML = "";
  const q = state.query.trim();

  if (q) {
    renderSearchResults(main, q);
    return;
  }

  if (state.section === "favorites") {
    renderFavorites(main);
    return;
  }
  if (state.section === "aircraft") {
    renderAircraft(main);
    return;
  }
  if (state.section === "tools") {
    renderTools(main);
    return;
  }

  const sec = SECTIONS.find(s => s.id === state.section);
  const head = document.createElement("div");
  head.className = "section-head";
  head.innerHTML = `<h1>${sec.label}</h1>`;
  main.appendChild(head);

  const grid = document.createElement("div");
  grid.className = "card-grid";
  (CARDS[sec.id] || []).forEach((c, i) => grid.appendChild(renderCard(sec.id, c, i, sec.color, "")));
  main.appendChild(grid);
}

function renderSearchResults(main, q) {
  const head = document.createElement("div");
  head.className = "section-head";
  head.innerHTML = `<h1>Search</h1>`;
  main.appendChild(head);
  const sub = document.createElement("div");
  sub.className = "section-sub";
  main.appendChild(sub);

  const grid = document.createElement("div");
  grid.className = "card-grid";
  let count = 0;
  SECTIONS.filter(s => s.id !== "tools").forEach(sec => {
    (CARDS[sec.id] || []).forEach((c, i) => {
      if (cardMatches(c, q)) {
        count++;
        grid.appendChild(renderCard(sec.id, c, i, sec.color, q));
      }
    });
  });
  sub.textContent = `${count} result${count === 1 ? "" : "s"} for \u201c${q}\u201d`;
  if (count === 0) {
    main.appendChild(emptyState("No matches", "Try a different term \u2014 or browse a section from the left."));
  } else {
    main.appendChild(grid);
  }
}

function renderFavorites(main) {
  const head = document.createElement("div");
  head.className = "section-head";
  head.innerHTML = `<h1>Favorites</h1>`;
  main.appendChild(head);
  const grid = document.createElement("div");
  grid.className = "card-grid";
  let count = 0;
  SECTIONS.filter(s => s.id !== "tools").forEach(sec => {
    (CARDS[sec.id] || []).forEach((c, i) => {
      if (state.favorites.has(cardKey(sec.id, i))) {
        count++;
        grid.appendChild(renderCard(sec.id, c, i, sec.color, ""));
      }
    });
  });
  if (count === 0) {
    main.appendChild(emptyState("No favorites yet", "Tap the star on any card to pin it here for quick access."));
  } else {
    main.appendChild(grid);
  }
}

function emptyState(big, small) {
  const div = document.createElement("div");
  div.className = "empty-state";
  div.innerHTML = `<div class="big">${big}</div><div>${small}</div>`;
  return div;
}

/* =========================================================================
   TOOLS (currency calculators)
   ========================================================================= */
function monthsBetween(d1, d2) {
  return (d2.getFullYear() - d1.getFullYear()) * 12 + (d2.getMonth() - d1.getMonth()) +
         (d2.getDate() >= d1.getDate() ? 0 : -1);
}
function addMonths(date, n) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + n);
  return d;
}
function fmtDate(d) {
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function renderTools(main) {
  const head = document.createElement("div");
  head.className = "section-head";
  head.innerHTML = `<h1>Tools</h1>`;
  main.appendChild(head);
  const sub = document.createElement("div");
  sub.className = "section-sub";
  sub.textContent = "Crosswind and currency calculators \u2014 estimates only. Verify against your logbook and current regulations.";
  main.appendChild(sub);

  const grid = document.createElement("div");
  grid.className = "tools-grid";
  grid.appendChild(buildCrosswindTool());

  grid.appendChild(buildTool(
    "Instrument currency (61.57c)",
    "Date of your most recent qualifying approach/holding/tracking activity.",
    "lastHitsDate",
    (val, box) => {
      const last = new Date(val);
      const now = new Date();
      const m = monthsBetween(last, now);
      if (m <= 6) {
        const due = addMonths(last, 6);
        box.className = "result-box ok";
        box.innerHTML = `<span class="status">Current</span>Instrument currency good through <b>${fmtDate(due)}</b>.`;
      } else if (m <= 12) {
        const due = addMonths(last, 12);
        box.className = "result-box warn";
        box.innerHTML = `<span class="status">Grace period</span>Currency lapsed \u2014 you have until <b>${fmtDate(due)}</b> to regain it with a safety pilot, instructor, or examiner (simulated conditions OK) before an IPC is required.`;
      } else {
        box.className = "result-box bad";
        box.innerHTML = `<span class="status">IPC required</span>More than 12 months since your last qualifying activity \u2014 an Instrument Proficiency Check is required before acting as PIC under IFR.`;
      }
    }
  ));

  grid.appendChild(buildTool(
    "Flight review (61.56)",
    "Date of your most recent flight review (or equivalent).",
    "lastReviewDate",
    (val, box) => {
      const last = new Date(val);
      const now = new Date();
      const m = monthsBetween(last, now);
      const due = addMonths(last, 24);
      if (m < 24) {
        box.className = "result-box ok";
        box.innerHTML = `<span class="status">Current</span>Flight review good through <b>${fmtDate(due)}</b>.`;
      } else {
        box.className = "result-box bad";
        box.innerHTML = `<span class="status">Overdue</span>Flight review lapsed on <b>${fmtDate(due)}</b>. A new review (or equivalent per 61.56) is required to act as PIC.`;
      }
    }
  ));

  grid.appendChild(buildTool(
    "Passenger currency \u2014 day (61.57a)",
    "Date of your most recent takeoff and landing.",
    "lastTOLDate",
    (val, box) => {
      const last = new Date(val);
      const now = new Date();
      const days = Math.floor((now - last) / 86400000);
      const due = new Date(last); due.setDate(due.getDate() + 90);
      if (days <= 90) {
        box.className = "result-box ok";
        box.innerHTML = `<span class="status">Current</span>Day passenger currency good through <b>${fmtDate(due)}</b> (needs 3 T/O &amp; landings in the preceding 90 days).`;
      } else {
        box.className = "result-box bad";
        box.innerHTML = `<span class="status">Lapsed</span>90-day window closed on <b>${fmtDate(due)}</b>. Fly 3 takeoffs and landings before carrying passengers.`;
      }
    }
  ));

  grid.appendChild(buildTool(
    "Passenger currency \u2014 night (61.57b)",
    "Date of your most recent full-stop night landing.",
    "lastNightDate",
    (val, box) => {
      const last = new Date(val);
      const now = new Date();
      const days = Math.floor((now - last) / 86400000);
      const due = new Date(last); due.setDate(due.getDate() + 90);
      if (days <= 90) {
        box.className = "result-box ok";
        box.innerHTML = `<span class="status">Current</span>Night passenger currency good through <b>${fmtDate(due)}</b> (needs 3 full-stop landings, 1 hr after sunset to 1 hr before sunrise, in the preceding 90 days).`;
      } else {
        box.className = "result-box bad";
        box.innerHTML = `<span class="status">Lapsed</span>90-day window closed on <b>${fmtDate(due)}</b>. Fly 3 full-stop night landings before carrying passengers at night.`;
      }
    }
  ));

  main.appendChild(grid);
}

function buildTool(title, desc, inputId, onCompute) {
  const card = document.createElement("div");
  card.className = "tool-card";
  card.innerHTML = `
    <h3>${title}</h3>
    <p class="desc">${desc}</p>
    <label for="${inputId}">DATE</label>
    <input type="date" id="${inputId}" />
    <div class="result-box" id="${inputId}_result">Enter a date to see status.</div>
  `;
  const input = card.querySelector("#" + inputId);
  const box = card.querySelector("#" + inputId + "_result");
  input.addEventListener("change", () => {
    if (!input.value) { box.className = "result-box"; box.textContent = "Enter a date to see status."; return; }
    onCompute(input.value, box);
  });
  return card;
}

/* =========================================================================
   INIT
   ========================================================================= */

/* =========================================================================
   AIRCRAFT EMERGENCY LIBRARY
   Model list is built in. Procedure steps are entered and verified by the
   user against their own approved POH/AFM and stored on this device.
   Flags: M = multi-engine, R = retractable gear
   ========================================================================= */
const AC_LIB = {
  "Cessna": [["150",""],["152",""],["172P",""],["172S",""],["172RG","R"],["177 Cardinal",""],["177RG Cardinal","R"],["182 (fixed-gear)",""],["182RG","R"],["206 / T206",""],["210 Centurion","R"],["310","MR"],["340","MR"]],
  "Piper": [["PA-28-180 Cherokee 180",""],["PA-28-140 Cherokee",""],["PA-28-161 Warrior",""],["PA-28-181 Archer",""],["PA-28R Arrow","R"],["PA-32 Cherokee Six",""],["PA-32R Lance / Saratoga","R"],["PA-34-200 Seneca I","MR"],["PA-34-200T Seneca II","MRT"],["PA-34-220T Seneca III","MRT"],["PA-34-220T Seneca IV","MRT"],["PA-44 Seminole","MR"],["PA-46 Malibu / Mirage","R"]],
  "Diamond": [["DA20",""],["DA40",""],["DA42","M"],["DA62","M"]],
  "Cirrus": [["SR20",""],["SR22 / SR22T",""]],
  "Beechcraft": [["Musketeer / Sundowner",""],["Bonanza F33 / A36","R"],["Bonanza V35","R"],["Baron 55 / 58","MR"],["Duchess 76","MR"]],
  "Mooney": [["M20 series","R"]],
  "Grumman / AA-5": [["AA-5 Traveler / Cheetah / Tiger",""]],
  "Tecnam": [["P2008",""],["P2006T","MR"]],
};
const AC_CATS_COMMON = [
  { id: "eng_fire", t: "Engine fire in flight", g: "Execute your POH engine fire checklist. Memory items differ by model, so enter yours and verify them." },
  { id: "elec_fire", t: "Electrical fire / smoke in the cabin", g: "Follow the POH. Common themes: master/avionics per checklist, ventilate, land as soon as possible." },
  { id: "alt_fail", t: "Alternator / generator failure", g: "Follow the POH. Shed electrical load to extend battery time, and note IFR consequences (radios, gyros, transponder)." },
  { id: "vac", t: "Vacuum / gyro failure", g: "Cross-check attitude and heading against the turn coordinator and compass, tell ATC you are on partial panel, and consider VFR conditions if available." },
  { id: "pitot", t: "Pitot / static blockage", g: "Use pitot heat, then the alternate static source if the airplane has one. See the Emergency tab for instrument effects." },
  { id: "oil", t: "Loss of oil pressure / high oil temperature", g: "Follow the POH. Treat it as a probable impending engine failure and plan a landing site." },
  { id: "rough", t: "Rough running engine / carburetor or induction ice", g: "Follow the POH. Typical steps involve carb heat or alternate air, mixture, fuel selector, and magnetos." },
  { id: "fuel", t: "Fuel starvation / fuel exhaustion", g: "Follow the POH. Switch tanks, boost pump, mixture, and confirm fuel quantity. Plan a landing early." },
];
const AC_CATS_SINGLE = [
  { id: "eng_to", t: "Engine failure on takeoff / after liftoff", g: "Lower the nose first and hold best-glide airspeed. Land straight ahead or within a small turn. Decide your turn-back altitude in the briefing, not in the emergency." },
  { id: "eng_flt", t: "Engine failure in flight and restart", g: "Pitch for best glide, pick a landing area, run your restart checklist, squawk 7700, and call on 121.5 if not already talking to ATC." },
];
const AC_CATS_MULTI = [
  { id: "eng_to_m", t: "Engine failure during takeoff / after liftoff (multi)", g: "Control the airplane first. Standard flow: full power, reduce drag, identify, verify, feather. Maintain at least Vyse and keep zero sideslip." },
  { id: "eng_flt_m", t: "Engine failure in cruise (multi)", g: "Control, then full power, reduce drag, identify, verify, fix or feather. Fly Vyse and plan the nearest suitable airport." },
  { id: "eng_land_m", t: "Single-engine approach, landing and go-around (multi)", g: "Fly a stabilized approach, delay gear and flaps until landing is assured, and know the go-around rule for your model. Many models climb poorly on one engine." },
];
const AC_CAT_GEAR = { id: "gear", t: "Landing gear malfunction / manual extension", g: "Follow the POH for manual extension or a gear-up landing. Confirm indications, recycle per the checklist, then plan the landing." };

function acCats(flags) {
  let cats = flags.includes("M") ? [...AC_CATS_MULTI] : [...AC_CATS_SINGLE];
  cats = cats.concat(AC_CATS_COMMON);
  if (flags.includes("R")) cats.push(AC_CAT_GEAR);
  return cats;
}

let acLoaded = false, acData = {};
function loadAc() {
  if (acLoaded) return;
  acLoaded = true;
  try { const r = localStorage.getItem("qrh_aircraft"); if (r) acData = JSON.parse(r) || {}; } catch (e) {}
  if (!acData.__custom) acData.__custom = [];
}
function saveAc() {
  try { localStorage.setItem("qrh_aircraft", JSON.stringify(acData)); } catch (e) {}
  if (window.qrhSync) qrhSync.markDirty();
}

function acAllManus() {
  const m = Object.keys(AC_LIB);
  acData.__custom.forEach(c => { if (!m.includes(c.m)) m.push(c.m); });
  return m;
}
function acModelsFor(manu) {
  const list = (AC_LIB[manu] || []).map(([n, f]) => ({ name: n, flags: f }));
  acData.__custom.filter(c => c.m === manu).forEach(c => list.push({ name: c.name, flags: c.flags || "" }));
  return list;
}
function acKey(manu, name) { return manu + "|" + name; }
function acProgress(manu, mod) {
  const cats = acCats(mod.flags);
  const rec = acData[acKey(manu, mod.name)] || { procs: {} };
  let entered = 0, verified = 0;
  cats.forEach(c => {
    const p = rec.procs && rec.procs[c.id];
    if (p && p.steps && p.steps.trim()) { entered++; if (p.verified) verified++; }
  });
  return { total: cats.length, entered, verified };
}

function renderAircraft(main) {
  loadAc();
  if (!state.acManu) state.acManu = "Cessna";
  if (state.acIO === undefined) state.acIO = null;

  const head = document.createElement("div");
  head.className = "section-head";
  head.innerHTML = "<h1>Aircraft Emergency Library</h1>";
  main.appendChild(head);

  const banner = document.createElement("div");
  banner.className = "banner";
  banner.innerHTML = "<b>Use your approved POH/AFM.</b> Emergency procedures differ by model, year, and equipment. This library holds the steps you enter and verify against your own current POH/AFM, saved on this device and, when you are signed in, synced to your private account. Generic reminders are not aircraft-specific. Until an entry is marked verified, treat it as a draft.";
  main.appendChild(banner);

  const tb = document.createElement("div");
  tb.className = "toolbar";
  acAllManus().forEach(m => {
    const c = document.createElement("div");
    c.className = "chip" + (state.acManu === m ? " active" : "");
    c.textContent = m;
    c.onclick = () => { state.acManu = m; state.acModel = null; renderAll(); };
    tb.appendChild(c);
  });
  const spacer = document.createElement("div"); spacer.style.flex = "1"; tb.appendChild(spacer);
  const addBtn = document.createElement("button"); addBtn.className = "btn"; addBtn.textContent = "Add aircraft";
  addBtn.onclick = () => { state.acIO = state.acIO === "add" ? null : "add"; renderAll(); };
  const expBtn = document.createElement("button"); expBtn.className = "btn"; expBtn.textContent = "Export / import";
  expBtn.onclick = () => { state.acIO = state.acIO === "io" ? null : "io"; renderAll(); };
  tb.appendChild(addBtn); tb.appendChild(expBtn);
  main.appendChild(tb);

  if (state.acIO === "add") main.appendChild(buildAddPanel());
  if (state.acIO === "io") main.appendChild(buildIOPanel());

  if (state.acModel) {
    const mod = acModelsFor(state.acManu).find(x => x.name === state.acModel);
    if (mod) { main.appendChild(buildModelDetail(state.acManu, mod)); return; }
    state.acModel = null;
  }

  const grid = document.createElement("div");
  grid.className = "card-grid";
  acModelsFor(state.acManu).forEach(mod => {
    const pr = acProgress(state.acManu, mod);
    const card = document.createElement("div");
    card.className = "model-card";
    const tags = (mod.flags.includes("M") ? '<span class="tag">Multi-engine</span>' : '<span class="tag">Single-engine</span>') +
                 (mod.flags.includes("R") ? '<span class="tag">Retractable</span>' : '') +
                 (mod.flags.includes("T") ? '<span class="tag">Turbocharged</span>' : '');
    card.innerHTML = '<div class="mname"></div><div class="mmeta">' + tags + '</div><div class="mprog">' + pr.entered + ' of ' + pr.total + ' entered \u00b7 ' + pr.verified + ' verified</div>';
    card.querySelector(".mname").textContent = state.acManu + " " + mod.name;
    card.onclick = () => { state.acModel = mod.name; renderAll(); };
    grid.appendChild(card);
  });
  main.appendChild(grid);
}

function buildModelDetail(manu, mod) {
  const wrap = document.createElement("div");
  const back = document.createElement("span");
  back.className = "back-link";
  back.textContent = "\u2190 All " + manu + " models";
  back.onclick = () => { state.acModel = null; renderAll(); };
  wrap.appendChild(back);

  const h = document.createElement("h2");
  h.style.cssText = "margin:0 0 14px;font-size:18px";
  h.textContent = manu + " " + mod.name;
  wrap.appendChild(h);

  const key = acKey(manu, mod.name);
  if (!acData[key]) acData[key] = { speeds: {}, procs: {} };
  const rec = acData[key];
  if (!rec.speeds) rec.speeds = {};
  if (!rec.procs) rec.procs = {};

  const speeds = mod.flags.includes("M")
    ? [["vyse","Vyse (blue line)"],["vsse","Vsse"],["vmc","Vmc"],["vxse","Vxse"],["vg","Best glide (if applicable)"],["xwind","Demo. crosswind (kt)"]]
    : [["vg","Best glide"],["vx","Vx"],["vy","Vy"],["vfe","Vfe"],["xwind","Demo. crosswind (kt)"]];
  const sg = document.createElement("div");
  sg.className = "speed-grid";
  speeds.forEach(([k, lab]) => {
    const d = document.createElement("div");
    const l = document.createElement("label"); l.textContent = lab.toUpperCase();
    const i = document.createElement("input"); i.type = "text"; i.placeholder = k === "xwind" ? "KT" : "KIAS"; i.value = rec.speeds[k] || "";
    i.addEventListener("change", () => { rec.speeds[k] = i.value; saveAc(); });
    d.appendChild(l); d.appendChild(i); sg.appendChild(d);
  });
  wrap.appendChild(sg);
  const wbBtn = document.createElement("button");
  wbBtn.className = "btn";
  wbBtn.style.marginBottom = "14px";
  wbBtn.textContent = state.acWB ? "Hide weight & balance" : "Weight & balance for this aircraft";
  wbBtn.onclick = () => { state.acWB = !state.acWB; renderAll(); };
  wrap.appendChild(wbBtn);
  if (state.acWB) {
    if (!rec.wb) rec.wb = wbDefaults();
    wrap.appendChild(buildWB(rec.wb));
  }

  if (window.qrhSync) wrap.appendChild(qrhSync.docsPanel(manu, mod.name));

  const grid = document.createElement("div");
  grid.className = "card-grid";
  acCats(mod.flags).forEach(cat => {
    if (!rec.procs[cat.id]) rec.procs[cat.id] = { steps: "", source: "", verified: false };
    const p = rec.procs[cat.id];
    const card = document.createElement("div");
    card.className = "card";
    const title = document.createElement("div");
    title.className = "card-title";
    const ts = document.createElement("span");
    const dot = document.createElement("span");
    const setDot = () => { dot.className = "status-dot" + (p.steps.trim() ? (p.verified ? " verified" : " entered") : ""); };
    setDot();
    ts.appendChild(dot); ts.appendChild(document.createTextNode(cat.t));
    title.appendChild(ts);
    card.appendChild(title);

    const hint = document.createElement("p");
    hint.className = "hint";
    hint.textContent = "Generic reminder: " + cat.g;
    card.appendChild(hint);

    const ta = document.createElement("textarea");
    ta.className = "steps";
    ta.placeholder = "One step per line, copied from your POH/AFM";
    ta.value = p.steps;
    ta.addEventListener("input", () => { p.steps = ta.value; saveAc(); setDot(); });
    card.appendChild(ta);

    const mr = document.createElement("div");
    mr.className = "meta-row";
    const src = document.createElement("input");
    src.type = "text"; src.className = "ac-input"; src.placeholder = "Source and revision (e.g. POH section, date)";
    src.value = p.source;
    src.addEventListener("input", () => { p.source = src.value; saveAc(); });
    const vl = document.createElement("label"); vl.className = "verify";
    const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!p.verified;
    cb.addEventListener("change", () => { p.verified = cb.checked; saveAc(); setDot(); });
    vl.appendChild(cb); vl.appendChild(document.createTextNode("Verified against POH"));
    mr.appendChild(src); mr.appendChild(vl);
    card.appendChild(mr);
    grid.appendChild(card);
  });
  wrap.appendChild(grid);
  return wrap;
}

function buildAddPanel() {
  const panel = document.createElement("div");
  panel.className = "io-panel";
  panel.innerHTML = '<div style="font-size:13px;margin-bottom:10px">Add a manufacturer or model that is not in the list.</div>';
  const row = document.createElement("div");
  row.className = "meta-row";
  const m = document.createElement("input"); m.type = "text"; m.className = "ac-input"; m.placeholder = "Manufacturer"; m.value = state.acManu || "";
  const n = document.createElement("input"); n.type = "text"; n.className = "ac-input"; n.placeholder = "Model";
  const multi = document.createElement("label"); multi.className = "verify";
  const mc = document.createElement("input"); mc.type = "checkbox"; multi.appendChild(mc); multi.appendChild(document.createTextNode("Multi-engine"));
  const gear = document.createElement("label"); gear.className = "verify";
  const gc = document.createElement("input"); gc.type = "checkbox"; gear.appendChild(gc); gear.appendChild(document.createTextNode("Retractable gear"));
  const go = document.createElement("button"); go.className = "btn primary"; go.textContent = "Add";
  go.onclick = () => {
    const mv = m.value.trim(), nv = n.value.trim();
    if (!mv || !nv) return;
    acData.__custom.push({ m: mv, name: nv, flags: (mc.checked ? "M" : "") + (gc.checked ? "R" : "") });
    saveAc();
    state.acManu = mv; state.acModel = nv; state.acIO = null;
    renderAll();
  };
  [m, n, multi, gear, go].forEach(e => row.appendChild(e));
  panel.appendChild(row);
  return panel;
}

function buildIOPanel() {
  const panel = document.createElement("div");
  panel.className = "io-panel";
  panel.innerHTML = '<div style="font-size:13px;margin-bottom:8px">Your entries are saved on this device and synced to your account when you are signed in. Copy the text below to keep a backup, or paste a backup here and choose Import.</div>';
  const ta = document.createElement("textarea");
  ta.value = JSON.stringify(acData, null, 1);
  panel.appendChild(ta);
  const row = document.createElement("div");
  row.className = "meta-row";
  const cp = document.createElement("button"); cp.className = "btn"; cp.textContent = "Copy";
  cp.onclick = () => { ta.select(); try { navigator.clipboard.writeText(ta.value); } catch (e) { try { document.execCommand("copy"); } catch (e2) {} } };
  const im = document.createElement("button"); im.className = "btn primary"; im.textContent = "Import";
  const msg = document.createElement("span"); msg.style.cssText = "font-size:12px;color:var(--text-dim)";
  im.onclick = () => {
    try {
      const obj = JSON.parse(ta.value);
      if (!obj || typeof obj !== "object") throw new Error("bad");
      if (!obj.__custom) obj.__custom = [];
      acData = obj; saveAc(); state.acModel = null; state.acIO = null; renderAll();
    } catch (e) { msg.textContent = "That text is not a valid backup. Nothing was changed."; }
  };
  row.appendChild(cp); row.appendChild(im); row.appendChild(msg);
  panel.appendChild(row);
  return panel;
}


/* =========================================================================
   WEIGHT AND BALANCE (per aircraft model, user-entered data)
   ========================================================================= */
function wbDefaults() {
  return { basicWt: "", basicArm: "", maxRamp: "", maxTO: "", maxLdg: "", stations: [], envelope: "", burn: "" };
}
function pnum(v) { const n = parseFloat(v); return isNaN(n) ? null : n; }

function parseEnvelope(txt) {
  const pts = [];
  (txt || "").split("\n").forEach(line => {
    const m = line.trim().split(/[\s,;]+/);
    if (m.length >= 2) {
      const cg = parseFloat(m[0]), w = parseFloat(m[1]);
      if (!isNaN(cg) && !isNaN(w)) pts.push({ cg: cg, w: w });
    }
  });
  return pts;
}
function onEdge(pt, poly) {
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[j], b = poly[i];
    const len = Math.hypot(b.cg - a.cg, b.w - a.w) || 1;
    const cross = (pt.cg - a.cg) * (b.w - a.w) - (pt.w - a.w) * (b.cg - a.cg);
    if (Math.abs(cross) > 0.005 * len) continue;
    if (pt.cg >= Math.min(a.cg, b.cg) - 0.005 && pt.cg <= Math.max(a.cg, b.cg) + 0.005 &&
        pt.w >= Math.min(a.w, b.w) - 0.005 && pt.w <= Math.max(a.w, b.w) + 0.005) return true;
  }
  return false;
}
function inPoly(pt, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].cg, yi = poly[i].w, xj = poly[j].cg, yj = poly[j].w;
    if (((yi > pt.w) !== (yj > pt.w)) && (pt.cg < (xj - xi) * (pt.w - yi) / (yj - yi) + xi)) inside = !inside;
  }
  return inside;
}
function inEnvelope(pt, poly) { return onEdge(pt, poly) || inPoly(pt, poly); }

const AVGAS_LB_PER_GAL = 6.0;

function computeWB(wb) {
  const bw = pnum(wb.basicWt), ba = pnum(wb.basicArm);
  if (bw === null || ba === null) {
    return { error: "Enter basic empty weight and arm from this airplane's current weight and balance record." };
  }
  let w = bw, mom = bw * ba, skipped = 0, fuelArm = null;
  wb.stations.forEach(st => {
    const arm = pnum(st.arm), q = pnum(st.wt);
    if (st.unit === "gal" && arm !== null && fuelArm === null) fuelArm = arm;
    if (q === null || q === 0) return;
    if (arm === null) { skipped++; return; }
    const lb = st.unit === "gal" ? q * AVGAS_LB_PER_GAL : q;
    w += lb; mom += lb * arm;
  });
  const out = { w: w, mom: mom, cg: mom / w, skipped: skipped, landing: null };
  const burn = pnum(wb.burn);
  if (burn && burn > 0 && fuelArm !== null) {
    const lw = w - burn * AVGAS_LB_PER_GAL;
    const lmom = mom - burn * AVGAS_LB_PER_GAL * fuelArm;
    if (lw > 0) out.landing = { w: lw, mom: lmom, cg: lmom / lw };
  }
  return out;
}

function wbChart(env, pts) {
  const NS = "http://www.w3.org/2000/svg";
  const W = 360, H = 250, padL = 48, padR = 14, padT = 12, padB = 34;
  const xs = env.map(p => p.cg).concat(pts.map(p => p.cg));
  const ys = env.map(p => p.w).concat(pts.map(p => p.w));
  let x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs);
  let y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
  const dx = (x1 - x0) || 1, dy = (y1 - y0) || 1;
  x0 -= dx * 0.06; x1 += dx * 0.06; y0 -= dy * 0.06; y1 += dy * 0.06;
  const X = v => padL + (v - x0) / (x1 - x0) * (W - padL - padR);
  const Y = v => H - padB - (v - y0) / (y1 - y0) * (H - padT - padB);
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 " + W + " " + H);
  svg.style.cssText = "width:100%;max-width:440px;display:block;margin-top:12px";
  function add(tag, attrs, style, text) {
    const e = document.createElementNS(NS, tag);
    Object.keys(attrs).forEach(k => e.setAttribute(k, attrs[k]));
    if (style) e.setAttribute("style", style);
    if (text !== undefined) e.textContent = text;
    svg.appendChild(e);
    return e;
  }
  add("polygon", { points: env.map(p => X(p.cg) + "," + Y(p.w)).join(" ") },
      "fill:var(--cyan);fill-opacity:0.12;stroke:var(--cyan);stroke-width:1.5");
  const dim = "fill:var(--text-dim);font-size:10px";
  add("text", { x: padL, y: H - 18, "text-anchor": "start" }, dim, x0.toFixed(1));
  add("text", { x: W - padR, y: H - 18, "text-anchor": "end" }, dim, x1.toFixed(1));
  add("text", { x: (padL + W - padR) / 2, y: H - 4, "text-anchor": "middle" }, dim, "CG (inches aft of datum)");
  add("text", { x: padL - 5, y: Y(y1) + 8, "text-anchor": "end" }, dim, Math.round(y1));
  add("text", { x: padL - 5, y: Y(y0), "text-anchor": "end" }, dim, Math.round(y0));
  add("text", { x: 10, y: (padT + H - padB) / 2, "text-anchor": "middle", transform: "rotate(-90 10 " + ((padT + H - padB) / 2) + ")" }, dim, "Weight (lb)");
  if (pts.length === 2) {
    add("line", { x1: X(pts[0].cg), y1: Y(pts[0].w), x2: X(pts[1].cg), y2: Y(pts[1].w) },
        "stroke:var(--text-faint);stroke-width:1;stroke-dasharray:3 3");
  }
  pts.forEach(pt => {
    const col = pt.ok ? pt.color : "var(--red)";
    add("circle", { cx: X(pt.cg), cy: Y(pt.w), r: 5 }, "fill:" + col + ";stroke:var(--bg);stroke-width:1.5");
    add("text", { x: X(pt.cg) + 8, y: Y(pt.w) + 3, "text-anchor": "start" }, "fill:var(--text);font-size:10px", pt.label);
  });
  return svg;
}

function buildWB(wb) {
  const box = document.createElement("div");
  box.className = "io-panel";
  const resultHost = document.createElement("div");

  function mkInput(key, ph) {
    const i = document.createElement("input");
    i.type = "text"; i.inputMode = "decimal"; i.className = "ac-input"; i.placeholder = ph || "";
    i.value = wb[key];
    i.addEventListener("input", () => { wb[key] = i.value; saveAc(); recalc(); });
    return i;
  }
  function field(label, key, ph) {
    const d = document.createElement("div");
    const l = document.createElement("label"); l.textContent = label;
    d.appendChild(l); d.appendChild(mkInput(key, ph));
    return d;
  }

  function recalc() {
    resultHost.innerHTML = "";
    const r = computeWB(wb);
    if (r.error) {
      const d = document.createElement("div");
      d.className = "result-box"; d.textContent = r.error;
      resultHost.appendChild(d);
      return;
    }
    const env = parseEnvelope(wb.envelope);
    const maxRamp = pnum(wb.maxRamp), maxTO = pnum(wb.maxTO), maxLdg = pnum(wb.maxLdg);
    const issues = [], notes = [], lines = [];
    const pts = [];

    lines.push("Takeoff (ramp) weight " + r.w.toFixed(0) + " lb, moment " + r.mom.toFixed(0) + ", CG " + r.cg.toFixed(2) + " in");
    if (maxRamp !== null && r.w > maxRamp) issues.push("Over maximum ramp weight by " + (r.w - maxRamp).toFixed(0) + " lb.");
    if (maxTO !== null && r.w > maxTO) issues.push("Over maximum takeoff weight by " + (r.w - maxTO).toFixed(0) + " lb.");
    if (maxRamp === null && maxTO === null) notes.push("No maximum weight entered, so weight limits were not checked.");

    if (env.length >= 3) {
      const ok = inEnvelope({ cg: r.cg, w: r.w }, env);
      pts.push({ cg: r.cg, w: r.w, label: "Takeoff", color: "var(--amber)", ok: ok });
      if (!ok) issues.push("Takeoff weight and CG fall outside the envelope.");
    } else {
      notes.push("Envelope not entered (need at least 3 points), so CG limits were not checked.");
    }

    if (r.landing) {
      const L = r.landing;
      lines.push("Landing weight " + L.w.toFixed(0) + " lb, CG " + L.cg.toFixed(2) + " in");
      if (maxLdg !== null && L.w > maxLdg) issues.push("Over maximum landing weight by " + (L.w - maxLdg).toFixed(0) + " lb.");
      if (env.length >= 3) {
        const ok = inEnvelope({ cg: L.cg, w: L.w }, env);
        pts.push({ cg: L.cg, w: L.w, label: "Landing", color: "var(--green)", ok: ok });
        if (!ok) issues.push("Landing weight and CG fall outside the envelope.");
      }
    } else if (pnum(wb.burn)) {
      notes.push("Fuel burn needs a fuel station in gallons with an arm entered.");
    }
    if (r.skipped > 0) notes.push(r.skipped + " loaded station(s) ignored because no arm was entered.");

    const cls = issues.length ? "bad" : (notes.length ? "warn" : "ok");
    const status = issues.length ? "Outside limits" : (notes.length ? "Within the limits you entered, with gaps" : "Within the limits you entered");
    const res = document.createElement("div");
    res.className = "result-box " + cls;
    const st = document.createElement("span"); st.className = "status"; st.textContent = status;
    res.appendChild(st);
    lines.concat(issues, notes).forEach(t => {
      const d = document.createElement("div"); d.className = "line"; d.textContent = t; res.appendChild(d);
    });
    const foot = document.createElement("div");
    foot.className = "line"; foot.style.color = "var(--text-faint)";
    foot.textContent = "Takeoff weight is taken as ramp weight with no taxi fuel deducted. This is a check against the numbers you entered. Verify against the POH and this airplane's current weight and balance record before flight.";
    res.appendChild(foot);
    resultHost.appendChild(res);
    if (env.length >= 3) resultHost.appendChild(wbChart(env, pts));
  }

  function redraw() {
    box.innerHTML = "";
    const intro = document.createElement("div");
    intro.style.cssText = "font-size:12.6px;color:var(--text-dim);line-height:1.5";
    intro.textContent = "Take empty weight and arm from this airplane's current weight and balance record, and the limits, station arms and envelope from the POH. Weights in pounds, arms in inches aft of the datum. Avgas is calculated at 6.0 lb per gallon.";
    box.appendChild(intro);

    const lim = document.createElement("div");
    lim.className = "wb-limits";
    lim.appendChild(field("BASIC EMPTY WEIGHT (LB)", "basicWt", "lb"));
    lim.appendChild(field("BASIC EMPTY ARM (IN)", "basicArm", "in"));
    lim.appendChild(field("MAX RAMP WEIGHT (LB)", "maxRamp", "optional"));
    lim.appendChild(field("MAX TAKEOFF WEIGHT (LB)", "maxTO", "lb"));
    lim.appendChild(field("MAX LANDING WEIGHT (LB)", "maxLdg", "lb"));
    box.appendChild(lim);

    const t1 = document.createElement("div"); t1.className = "wb-section-title"; t1.textContent = "Loading stations";
    box.appendChild(t1);
    const head = document.createElement("div");
    head.className = "wbrow head";
    ["STATION", "ARM (IN)", "AMOUNT", "UNIT", ""].forEach(h => { const d = document.createElement("div"); d.textContent = h; head.appendChild(d); });
    box.appendChild(head);

    wb.stations.forEach((st, idx) => {
      const row = document.createElement("div");
      row.className = "wbrow";
      const name = document.createElement("input"); name.type = "text"; name.className = "ac-input"; name.value = st.name; name.placeholder = "Station";
      name.addEventListener("input", () => { st.name = name.value; saveAc(); });
      const arm = document.createElement("input"); arm.type = "text"; arm.inputMode = "decimal"; arm.className = "ac-input"; arm.value = st.arm; arm.placeholder = "arm";
      arm.addEventListener("input", () => { st.arm = arm.value; saveAc(); recalc(); });
      const amt = document.createElement("input"); amt.type = "text"; amt.inputMode = "decimal"; amt.className = "ac-input"; amt.value = st.wt; amt.placeholder = "0";
      amt.addEventListener("input", () => { st.wt = amt.value; saveAc(); recalc(); });
      const unit = document.createElement("select"); unit.className = "ac-input";
      [["lb", "lb"], ["gal", "gal avgas"]].forEach(([v, l]) => { const o = document.createElement("option"); o.value = v; o.textContent = l; if (st.unit === v) o.selected = true; unit.appendChild(o); });
      unit.addEventListener("change", () => { st.unit = unit.value; saveAc(); recalc(); });
      const del = document.createElement("button"); del.className = "x-btn"; del.textContent = "\u00d7"; del.title = "Remove station";
      del.onclick = () => { wb.stations.splice(idx, 1); saveAc(); redraw(); };
      [name, arm, amt, unit, del].forEach(e => row.appendChild(e));
      box.appendChild(row);
    });

    const adds = document.createElement("div");
    adds.className = "toolbar"; adds.style.marginTop = "8px";
    [["Front seats", "lb"], ["Rear seats", "lb"], ["Baggage", "lb"], ["Fuel", "gal"], ["Other", "lb"]].forEach(([n, u]) => {
      const b = document.createElement("button"); b.className = "btn"; b.textContent = "+ " + n;
      b.onclick = () => { wb.stations.push({ name: n, arm: "", wt: "", unit: u }); saveAc(); redraw(); };
      adds.appendChild(b);
    });
    box.appendChild(adds);

    const t2 = document.createElement("div"); t2.className = "wb-section-title"; t2.textContent = "Landing check (optional)";
    box.appendChild(t2);
    const burnRow = document.createElement("div");
    burnRow.style.maxWidth = "260px";
    burnRow.appendChild(field("FUEL BURNED THIS FLIGHT (GAL)", "burn", "gal"));
    box.appendChild(burnRow);

    const t3 = document.createElement("div"); t3.className = "wb-section-title"; t3.textContent = "CG envelope";
    box.appendChild(t3);
    const envNote = document.createElement("div");
    envNote.style.cssText = "font-size:12px;color:var(--text-dim);margin-bottom:6px";
    envNote.textContent = "One point per line as CG, weight (for example 38.5, 1500), going around the envelope in order from the POH chart.";
    box.appendChild(envNote);
    const ta = document.createElement("textarea");
    ta.className = "steps"; ta.style.minHeight = "100px"; ta.style.fontFamily = "'IBM Plex Mono', monospace";
    ta.value = wb.envelope; ta.placeholder = "CG, weight";
    ta.addEventListener("input", () => { wb.envelope = ta.value; saveAc(); recalc(); });
    box.appendChild(ta);

    const t4 = document.createElement("div"); t4.className = "wb-section-title"; t4.textContent = "Result";
    box.appendChild(t4);
    box.appendChild(resultHost);
    recalc();
  }
  redraw();
  return box;
}

/* =========================================================================
   CROSSWIND CALCULATOR
   ========================================================================= */
function buildCrosswindTool() {
  loadAc();
  const card = document.createElement("div");
  card.className = "tool-card";
  card.innerHTML = '<h3>Crosswind and headwind</h3><p class="desc">Wind components for a runway. Tower and ATIS winds are magnetic; METAR and TAF winds are true, so convert before comparing to the runway heading.</p>';

  function mk(label, ph, type) {
    const wrap = document.createElement("div"); wrap.className = "field";
    const l = document.createElement("label"); l.textContent = label;
    const i = document.createElement("input"); i.type = "text"; i.inputMode = "decimal"; i.className = "ac-input"; i.placeholder = ph;
    wrap.appendChild(l); wrap.appendChild(i);
    return { wrap: wrap, input: i };
  }
  const rwy = mk("RUNWAY (1-36)", "e.g. 17");
  const dir = mk("WIND DIRECTION (DEG)", "e.g. 210");
  const spd = mk("WIND SPEED (KT)", "e.g. 14");
  const gst = mk("GUST (KT, OPTIONAL)", "e.g. 22");
  const two1 = document.createElement("div"); two1.className = "two"; two1.appendChild(rwy.wrap); two1.appendChild(dir.wrap);
  const two2 = document.createElement("div"); two2.className = "two"; two2.appendChild(spd.wrap); two2.appendChild(gst.wrap);
  card.appendChild(two1); card.appendChild(two2);

  const selWrap = document.createElement("div"); selWrap.className = "field";
  const selL = document.createElement("label"); selL.textContent = "AIRCRAFT (FILLS YOUR SAVED DEMONSTRATED CROSSWIND)";
  const sel = document.createElement("select"); sel.className = "ac-input";
  const none = document.createElement("option"); none.value = ""; none.textContent = "None selected"; sel.appendChild(none);
  acAllManus().forEach(m => {
    acModelsFor(m).forEach(mod => {
      const o = document.createElement("option"); o.value = acKey(m, mod.name); o.textContent = m + " " + mod.name; sel.appendChild(o);
    });
  });
  selWrap.appendChild(selL); selWrap.appendChild(sel);
  card.appendChild(selWrap);
  const lim = mk("CROSSWIND LIMIT (KT)", "demonstrated or personal");
  card.appendChild(lim.wrap);

  const out = document.createElement("div");
  out.className = "result-box"; out.textContent = "Enter runway, wind direction and wind speed.";
  card.appendChild(out);
  const note = document.createElement("p");
  note.className = "desc"; note.style.margin = "10px 0 0";
  note.textContent = "Demonstrated crosswind is not a legal limit. Use it with your own personal minimums.";
  card.appendChild(note);

  function comp(ws, ang) {
    const rad = ang * Math.PI / 180;
    return { x: ws * Math.sin(rad), h: ws * Math.cos(rad) };
  }
  function calc() {
    const r = pnum(rwy.input.value), wd = pnum(dir.input.value), ws = pnum(spd.input.value);
    const g = pnum(gst.input.value), limit = pnum(lim.input.value);
    out.innerHTML = "";
    if (r === null || wd === null || ws === null) { out.className = "result-box"; out.textContent = "Enter runway, wind direction and wind speed."; return; }
    if (r < 1 || r > 36) { out.className = "result-box warn"; out.textContent = "Runway number must be from 1 to 36."; return; }
    const hdg = r * 10;
    const ang = ((((wd - hdg) % 360) + 540) % 360) - 180;
    const steady = comp(ws, ang);
    const gustC = (g !== null && g > ws) ? comp(g, ang) : null;
    const worst = Math.max(Math.abs(steady.x), gustC ? Math.abs(gustC.x) : 0);
    const side = steady.x >= 0 ? "right" : "left";
    function desc(c) {
      const hw = c.h >= 0 ? Math.round(c.h) + " kt headwind" : Math.round(-c.h) + " kt tailwind";
      return Math.round(Math.abs(c.x)) + " kt crosswind from the " + (c.x >= 0 ? "right" : "left") + ", " + hw;
    }
    let cls = "result-box", status = "Components";
    if (limit !== null) {
      if (worst > limit) { cls += " bad"; status = "Exceeds your limit"; }
      else if (worst >= 0.8 * limit) { cls += " warn"; status = "Near your limit"; }
      else { cls += " ok"; status = "Within your limit"; }
    }
    out.className = cls;
    const st = document.createElement("span"); st.className = "status"; st.textContent = status; out.appendChild(st);
    const l1 = document.createElement("div"); l1.className = "line"; l1.textContent = "Runway " + r + ": " + desc(steady); out.appendChild(l1);
    if (gustC) {
      const l2 = document.createElement("div"); l2.className = "line"; l2.textContent = "With gusts: " + desc(gustC); out.appendChild(l2);
    }
    const rev = ((r + 17) % 36) + 1;
    const l3 = document.createElement("div"); l3.className = "line";
    l3.textContent = "Runway " + rev + " (opposite end): " + (steady.h > 0 ? Math.round(steady.h) + " kt tailwind" : Math.round(-steady.h) + " kt headwind");
    out.appendChild(l3);
  }
  [rwy.input, dir.input, spd.input, gst.input, lim.input].forEach(i => i.addEventListener("input", calc));
  sel.addEventListener("change", () => {
    const rec = acData[sel.value];
    lim.input.value = (rec && rec.speeds && rec.speeds.xwind) ? rec.speeds.xwind : "";
    calc();
  });
  return card;
}

function renderAll() {
  renderRail();
  renderMobileTabs();
  renderMain();
}

document.getElementById("search").addEventListener("input", (e) => {
  state.query = e.target.value;
  renderAll();
});

document.getElementById("favToggle").addEventListener("click", () => {
  state.section = state.section === "favorites" ? "preflight" : "favorites";
  state.query = "";
  document.getElementById("search").value = "";
  renderAll();
});

document.getElementById("themeToggle").addEventListener("click", () => {
  state.theme = state.theme === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", state.theme);
  document.getElementById("themeToggle").classList.toggle("active", state.theme === "light");
  saveTheme();
});

loadLocal();
document.documentElement.setAttribute("data-theme", state.theme);
if (state.theme === "light") document.getElementById("themeToggle").classList.add("active");
renderAll();
