/* Accounts, private sync and POH file storage. Loads after app.js.
   The app stays fully usable signed out and offline; this layer only adds sync on top. */
(function () {
  "use strict";

  var META_KEY = "qrh_sync_meta";
  var BACKUP_KEY = "qrh_overwritten";
  var MAX_PDF = 25 * 1024 * 1024;

  var S = { user: null, status: "signedout", lastSync: null, busy: false, again: false, timer: null, notice: "" };
  var meta = loadMeta();
  var changedLocal = false;
  var changedKeys = {};
  var pendingRender = false;
  var dialog = null;
  var dlg = { mode: "in", error: "", email: "", busy: false, confirmDelete: false };

  /* ------------------------------------------------------------------ utils */
  function el(tag, props, kids) {
    var e = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      var v = props[k];
      if (k === "class") e.className = v;
      else if (k === "text") e.textContent = v;
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    });
    (kids || []).forEach(function (c) {
      if (c) e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return e;
  }

  function hash(str) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0; i < str.length; i++) {
      var ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }

  function fillMeta(m) {
    m.uid = m.uid || null;
    m.email = m.email || null;
    m.hashes = m.hashes || {};   // hash of each doc as last synced
    m.versions = m.versions || {}; // server version of each doc as last synced
    m.updated = m.updated || {};   // when each doc was last changed locally
    m.seen = m.seen || {};         // hash at last local scan, to timestamp edits
    return m;
  }
  function loadMeta() {
    try {
      var m = JSON.parse(localStorage.getItem(META_KEY) || "null");
      if (m && typeof m === "object") return fillMeta(m);
    } catch (e) { /* ignore */ }
    return fillMeta({});
  }
  function saveMeta() {
    try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch (e) { /* storage unavailable */ }
  }

  function api(method, url, body, rawBody) {
    var opts = { method: method, credentials: "same-origin", headers: { "X-QRH-Client": "1" } };
    if (rawBody !== undefined) {
      opts.headers["Content-Type"] = "application/pdf";
      opts.body = rawBody;
    } else if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    return fetch(url, opts).then(function (r) {
      return r.text().then(function (t) {
        var data = null;
        try { data = t ? JSON.parse(t) : null; } catch (e) { /* not json */ }
        return { ok: r.ok, status: r.status, data: data };
      });
    });
  }
  function must(r) {
    if (r.status === 401) { var e = new Error("Not signed in."); e.code = 401; throw e; }
    if (!r.ok) throw new Error((r.data && r.data.error) || "Request failed (" + r.status + ")");
    return r;
  }

  /* ------------------------------------------------------- local documents */
  function hasContent(rec) {
    if (!rec || typeof rec !== "object") return false;
    var k;
    for (k in (rec.speeds || {})) if (String(rec.speeds[k] || "").trim()) return true;
    for (k in (rec.procs || {})) {
      var p = rec.procs[k] || {};
      if (String(p.steps || "").trim() || String(p.source || "").trim() || p.verified) return true;
    }
    var w = rec.wb;
    if (w && typeof w === "object") {
      for (k in w) {
        if (k === "stations") { if (w.stations && w.stations.length) return true; }
        else if (String(w[k] || "").trim()) return true;
      }
    }
    return false;
  }

  function currentDocs() {
    loadAc();
    var out = {};
    var favs = Array.from(state.favorites).sort();
    if (favs.length || meta.hashes.favorites !== undefined) out.favorites = favs;
    var custom = acData.__custom || [];
    if (custom.length || meta.hashes.custom !== undefined) out.custom = custom;
    Object.keys(acData).forEach(function (k) {
      if (k === "__custom") return;
      var dk = "ac:" + k;
      if (hasContent(acData[k]) || meta.hashes[dk] !== undefined) out[dk] = acData[k];
    });
    return out;
  }

  function validShape(key, v) {
    if (key === "favorites") {
      return Array.isArray(v) && v.length <= 500 && v.every(function (x) { return typeof x === "string" && x.length <= 100; });
    }
    if (key === "custom") {
      return Array.isArray(v) && v.length <= 200 && v.every(function (c) {
        return c && typeof c.m === "string" && typeof c.name === "string" && c.m.length <= 200 && c.name.length <= 200 &&
          (c.flags === undefined || typeof c.flags === "string");
      });
    }
    if (key.indexOf("ac:") === 0) {
      var name = key.slice(3);
      if (name.indexOf("|") < 1 || name.slice(0, 2) === "__") return false;
      return v && typeof v === "object" && !Array.isArray(v);
    }
    return false;
  }

  function persistAc() {
    try { localStorage.setItem("qrh_aircraft", JSON.stringify(acData)); } catch (e) { /* ignore */ }
  }
  function applyDoc(key, value) {
    loadAc();
    if (key === "favorites") {
      state.favorites = new Set(value);
      try { localStorage.setItem("qrh_favorites", JSON.stringify(Array.from(state.favorites))); } catch (e) { /* ignore */ }
    } else if (key === "custom") {
      acData.__custom = value;
      persistAc();
    } else {
      var rec = value;
      if (!rec.speeds || typeof rec.speeds !== "object") rec.speeds = {};
      if (!rec.procs || typeof rec.procs !== "object") rec.procs = {};
      acData[key.slice(3)] = rec;
      persistAc();
    }
    changedLocal = true;
    changedKeys[key] = true;
  }

  function backupLocal(key, value) {
    try {
      var list = JSON.parse(localStorage.getItem(BACKUP_KEY) || "[]");
      list.push({ key: key, value: value, at: Date.now() });
      localStorage.setItem(BACKUP_KEY, JSON.stringify(list.slice(-20)));
    } catch (e) { /* ignore */ }
    S.notice = "Some changes on this device were replaced by newer versions from your account.";
  }

  function scanDirty() {
    var cur = currentDocs();
    var now = Date.now();
    Object.keys(cur).forEach(function (k) {
      var h = hash(JSON.stringify(cur[k]));
      if (meta.seen[k] !== h) { meta.seen[k] = h; meta.updated[k] = now; }
    });
    saveMeta();
    return cur;
  }
  function dirtyKeys(cur) {
    return Object.keys(cur).filter(function (k) { return hash(JSON.stringify(cur[k])) !== meta.hashes[k]; });
  }

  /* ------------------------------------------------------------------ sync */
  function adoptServer(key, d, backup) {
    var cur = currentDocs();
    if (backup && cur[key] !== undefined) backupLocal(key, cur[key]);
    applyDoc(key, d.value);
    var after = currentDocs()[key];
    meta.versions[key] = d.version;
    meta.hashes[key] = hash(JSON.stringify(after));
    meta.seen[key] = meta.hashes[key];
    meta.updated[key] = d.updatedAt;
  }

  function union(key, a, b) {
    if (key === "favorites") return Array.from(new Set(a.concat(b))).sort();
    var seen = {}, out = [];
    a.concat(b).forEach(function (c) {
      var id = c.m + "|" + c.name;
      if (!seen[id]) { seen[id] = 1; out.push(c); }
    });
    return out;
  }

  async function pullAll() {
    var r = must(await api("GET", "/api/docs"));
    var docs = (r.data && r.data.docs) || [];
    var cur = currentDocs();
    docs.forEach(function (d) {
      var k = d.key;
      if (!validShape(k, d.value)) return;
      var local = cur[k];
      var known = meta.versions[k] !== undefined;
      if (!known) {
        // This device has never synced this document.
        if (local !== undefined && (k === "favorites" || k === "custom")) {
          applyDoc(k, union(k, local, d.value));
          meta.versions[k] = d.version;
          meta.updated[k] = Date.now();
          delete meta.hashes[k]; // merged result still has to be pushed
        } else if (local !== undefined && JSON.stringify(local) !== JSON.stringify(d.value)) {
          adoptServer(k, d, true); // account copy wins on first contact, local copy is kept as a backup
        } else {
          adoptServer(k, d, false);
        }
        return;
      }
      if (d.version === meta.versions[k]) return;
      var localDirty = local !== undefined && hash(JSON.stringify(local)) !== meta.hashes[k];
      if (!localDirty) adoptServer(k, d, false);
      else if (d.updatedAt > (meta.updated[k] || 0)) adoptServer(k, d, true);
      else meta.versions[k] = d.version; // local edit is newer; the push will win
    });
    saveMeta();
  }

  async function pushOne(key, value, retried) {
    var str = JSON.stringify(value);
    var r = await api("PUT", "/api/docs", {
      key: key,
      value: value,
      baseVersion: meta.versions[key] || 0,
      updatedAt: meta.updated[key] || Date.now(),
    });
    if (r.ok) {
      meta.versions[key] = r.data.version;
      meta.hashes[key] = hash(str);
      saveMeta();
      return;
    }
    if (r.status === 409 && r.data && r.data.current) {
      var srv = r.data.current;
      if (!retried && srv.updatedAt <= (meta.updated[key] || 0)) {
        meta.versions[key] = srv.version;
        return pushOne(key, value, true);
      }
      if (validShape(key, srv.value)) adoptServer(key, { value: srv.value, version: srv.version, updatedAt: srv.updatedAt }, true);
      saveMeta();
      return;
    }
    must(r);
  }

  async function pushAll() {
    var cur = currentDocs();
    var keys = dirtyKeys(cur);
    for (var i = 0; i < keys.length; i++) await pushOne(keys[i], cur[keys[i]], false);
  }

  async function sync() {
    if (!S.user) return;
    if (S.busy) { S.again = true; return; }
    S.busy = true;
    setStatus("syncing");
    try {
      await pullAll();
      if (changedLocal) { changedLocal = false; refreshView(); } // update the screen before any network push
      scanDirty();
      await pushAll();
      S.lastSync = Date.now();
      setStatus("synced");
    } catch (e) {
      if (e && e.code === 401) { S.user = null; setStatus("expired"); }
      else if (e instanceof TypeError) setStatus("offline");
      else { setStatus("error"); S.notice = (e && e.message) || "Sync failed."; refreshDialog(); }
    } finally {
      S.busy = false;
      if (S.again) { S.again = false; scheduleSync(300); }
    }
    if (changedLocal) { changedLocal = false; refreshView(); }
  }

  function scheduleSync(ms) {
    if (!S.user) return;
    clearTimeout(S.timer);
    S.timer = setTimeout(sync, ms === undefined ? 1500 : ms);
  }

  function typingInForm() {
    var a = document.activeElement;
    return a && (a.tagName === "TEXTAREA" || a.tagName === "INPUT" || a.tagName === "SELECT") && !!a.closest("main");
  }
  // Fields on the open aircraft page hold references to the records they edit. If a sync replaces
  // that record, the page must be rebuilt right away or later keystrokes would go to a stale copy.
  // Changes to anything else wait until the pilot leaves the text box, so typing is not interrupted.
  function refreshView() {
    var openKey = state.acModel ? "ac:" + state.acManu + "|" + state.acModel : null;
    var touchesOpen = !!(openKey && changedKeys[openKey]);
    if (typingInForm() && !touchesOpen) { pendingRender = true; return; }
    pendingRender = false;
    changedKeys = {};
    renderAll();
  }
  document.addEventListener("focusout", function () {
    if (!pendingRender) return;
    setTimeout(function () {
      if (!typingInForm()) { pendingRender = false; changedKeys = {}; renderAll(); }
    }, 0);
  });

  function markDirty() {
    if (!S.user && !meta.uid) return;
    scanDirty();
    scheduleSync();
  }

  /* --------------------------------------------------------------- account */
  function wipeLocal() {
    try {
      localStorage.removeItem("qrh_aircraft");
      localStorage.removeItem("qrh_favorites");
      localStorage.removeItem(BACKUP_KEY);
      localStorage.removeItem(META_KEY);
    } catch (e) { /* ignore */ }
    acData = { __custom: [] };
    state.favorites = new Set();
    state.acModel = null;
    state.acWB = false;
    meta = fillMeta({});
    changedLocal = false;
    changedKeys = {};
    pendingRender = false;
  }

  async function authRequest(path, email, password) {
    var r = await api("POST", "/api/auth/" + path, { email: email, password: password });
    if (!r.ok) throw new Error((r.data && r.data.error) || "Request failed.");
    return r.data.user;
  }

  async function onSignedIn(user) {
    if (meta.uid && meta.uid !== user.id) {
      var ok = window.confirm("This device still holds saved data from a different account. Signing in will remove that data from this device. Continue?");
      if (!ok) {
        try { await api("POST", "/api/auth/logout", {}); } catch (e) { /* ignore */ }
        throw new Error("Sign-in cancelled.");
      }
      wipeLocal();
    }
    S.user = user;
    meta.uid = user.id;
    meta.email = user.email;
    saveMeta();
    scanDirty();
    await sync();
    refreshView();
  }

  async function signOut() {
    if (S.user) { try { await sync(); } catch (e) { /* offline */ } }
    var unsynced = dirtyKeys(currentDocs()).length > 0;
    if (unsynced && !window.confirm("Some changes have not synced yet and will be removed from this device when you sign out. Sign out anyway?")) return;
    try { await api("POST", "/api/auth/logout", {}); } catch (e) { /* offline: server session expires on its own */ }
    S.user = null;
    wipeLocal();
    S.notice = "";
    setStatus("signedout");
    renderAll();
  }

  async function deleteAccount(password) {
    var r = await api("POST", "/api/auth/delete", { password: password });
    if (!r.ok) throw new Error((r.data && r.data.error) || "Could not delete the account.");
    S.user = null;
    wipeLocal();
    S.notice = "";
    setStatus("signedout");
    renderAll();
  }

  /* ----------------------------------------------------------------- status */
  var STATUS_TEXT = {
    signedout: "Not signed in. Your data stays on this device.",
    syncing: "Syncing...",
    synced: "Synced",
    offline: "Offline. Changes will sync when you are back online.",
    expired: "Your session expired. Your data on this device is safe. Sign in to resume syncing.",
    error: "Sync problem.",
  };
  function ago(ts) {
    if (!ts) return "";
    var s = Math.round((Date.now() - ts) / 1000);
    if (s < 10) return "just now";
    if (s < 60) return s + " seconds ago";
    var m = Math.round(s / 60);
    if (m < 60) return m + (m === 1 ? " minute ago" : " minutes ago");
    return new Date(ts).toLocaleString();
  }
  function setStatus(st) {
    S.status = st;
    var b = document.getElementById("accountBtn");
    if (b) {
      b.setAttribute("data-status", st);
      b.title = S.user ? "Account: " + S.user.email + " (" + STATUS_TEXT[st].replace(/\.$/, "") + ")" : "Account and sync";
    }
    refreshDialog();
  }

  /* ----------------------------------------------------------------- dialog */
  function ensureDialog() {
    if (dialog) return dialog;
    dialog = el("dialog", { class: "acct-dialog", "aria-labelledby": "acctTitle" });
    dialog.addEventListener("click", function (e) { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener("close", function () { dlg.error = ""; dlg.confirmDelete = false; });
    document.body.appendChild(dialog);
    return dialog;
  }
  function openAccount() {
    ensureDialog();
    renderDialog();
    if (!dialog.open) dialog.showModal();
  }
  function refreshDialog() {
    if (dialog && dialog.open) renderDialog();
  }

  function field(id, label, type, autocomplete, extra) {
    var input = el("input", Object.assign({ id: id, type: type, autocomplete: autocomplete, required: "required", class: "ac-input" }, extra || {}));
    return { row: el("div", { class: "acct-field" }, [el("label", { for: id, text: label }), input]), input: input };
  }

  function renderDialog() {
    dialog.innerHTML = "";
    var head = el("div", { class: "acct-head" }, [
      el("h2", { id: "acctTitle", text: S.user ? "Account" : (dlg.mode === "up" ? "Create account" : "Sign in") }),
      el("button", { class: "icon-btn", type: "button", "aria-label": "Close", onclick: function () { dialog.close(); }, text: "×" }),
    ]);
    dialog.appendChild(head);
    if (S.user) renderSignedIn(); else renderSignedOut();
  }

  function renderSignedOut() {
    var tabs = el("div", { class: "acct-tabs", role: "tablist" }, [
      el("button", { type: "button", role: "tab", "aria-selected": dlg.mode === "in" ? "true" : "false", class: "chip" + (dlg.mode === "in" ? " active" : ""), text: "Sign in", onclick: function () { dlg.mode = "in"; dlg.error = ""; renderDialog(); } }),
      el("button", { type: "button", role: "tab", "aria-selected": dlg.mode === "up" ? "true" : "false", class: "chip" + (dlg.mode === "up" ? " active" : ""), text: "Create account", onclick: function () { dlg.mode = "up"; dlg.error = ""; renderDialog(); } }),
    ]);
    dialog.appendChild(tabs);

    if (S.status === "expired") dialog.appendChild(el("p", { class: "acct-note warn", text: STATUS_TEXT.expired }));

    var up = dlg.mode === "up";
    var email = field("acctEmail", "Email", "email", "email", { value: dlg.email });
    email.input.addEventListener("input", function () { dlg.email = email.input.value; });
    var pw = field("acctPw", "Password", "password", up ? "new-password" : "current-password", up ? { minlength: "10", maxlength: "72" } : {});
    var err = el("p", { class: "acct-error", role: "alert", text: dlg.error });
    var submit = el("button", { class: "btn primary", type: "submit", text: up ? "Create account" : "Sign in" });
    var form = el("form", { class: "acct-form", novalidate: "novalidate" }, [email.row, pw.row, err, submit]);
    form.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      if (dlg.busy) return;
      var em = email.input.value.trim(), pass = pw.input.value;
      if (!em || !pass) { err.textContent = "Enter your email and password."; return; }
      dlg.busy = true;
      submit.disabled = true;
      err.textContent = "";
      try {
        var user = await authRequest(up ? "signup" : "login", em, pass);
        dlg.error = "";
        dlg.email = "";
        dlg.mode = "in"; // next time the signed-out dialog opens on Sign in
        await onSignedIn(user);
      } catch (e) {
        // Show the problem in place so the email the pilot typed is not lost.
        dlg.busy = false;
        err.textContent = e instanceof TypeError ? "Cannot reach the server. Check your connection." : e.message;
        submit.disabled = false;
        pw.input.value = "";
        pw.input.focus();
        return;
      }
      dlg.busy = false;
      renderDialog();
    });
    dialog.appendChild(form);

    dialog.appendChild(el("p", { class: "acct-note", text: up
      ? "Use at least 10 characters. Email password reset is not available yet, so keep your password somewhere safe."
      : "The app works without an account. Signing in syncs your aircraft notes, weight and balance data, favorites and POH files across your devices." }));
    dialog.appendChild(el("p", { class: "acct-note", text: "Your data is private to your account and is not shared with other pilots." }));
    setTimeout(function () { email.input.focus(); }, 0);
  }

  function renderSignedIn() {
    dialog.appendChild(el("p", { class: "acct-email", text: S.user.email }));
    var line = STATUS_TEXT[S.status] || "";
    if (S.status === "synced" && S.lastSync) line = "Synced " + ago(S.lastSync);
    dialog.appendChild(el("p", { class: "acct-status", "data-status": S.status, text: line }));
    if (S.notice) dialog.appendChild(el("p", { class: "acct-note warn", text: S.notice }));

    var row = el("div", { class: "acct-actions" }, [
      el("button", { class: "btn primary", type: "button", text: "Sync now", onclick: function () { sync(); } }),
      el("button", { class: "btn", type: "button", text: "Sign out", onclick: function () { dialog.close(); signOut(); } }),
    ]);
    dialog.appendChild(row);
    dialog.appendChild(el("p", { class: "acct-note", text: "Signing out removes your synced data from this device. It stays in your account." }));

    var danger = el("div", { class: "acct-danger" });
    if (!dlg.confirmDelete) {
      danger.appendChild(el("button", { class: "btn danger", type: "button", text: "Delete account...", onclick: function () { dlg.confirmDelete = true; renderDialog(); } }));
    } else {
      var pw = field("acctDelPw", "Confirm with your password", "password", "current-password");
      var err = el("p", { class: "acct-error", role: "alert", text: "" });
      var go = el("button", { class: "btn danger", type: "submit", text: "Permanently delete account and files" });
      var form = el("form", { class: "acct-form", novalidate: "novalidate" }, [
        el("p", { class: "acct-note warn", text: "This deletes your account, synced data and uploaded POH files from the server. It cannot be undone." }),
        pw.row, err, go,
      ]);
      form.addEventListener("submit", async function (ev) {
        ev.preventDefault();
        go.disabled = true;
        try {
          await deleteAccount(pw.input.value);
          dlg.confirmDelete = false;
          dialog.close();
        } catch (e) {
          err.textContent = e instanceof TypeError ? "Cannot reach the server." : e.message;
          go.disabled = false;
        }
      });
      danger.appendChild(form);
    }
    dialog.appendChild(danger);
  }

  /* ------------------------------------------------------- POH file panel */
  function fmtSize(n) {
    if (n < 1024 * 1024) return Math.max(1, Math.round(n / 1024)) + " KB";
    return (n / 1048576).toFixed(1) + " MB";
  }

  function docsPanel(manu, modelName) {
    var key = manu + "|" + modelName;
    var panel = el("div", { class: "io-panel docs-panel" });
    panel.appendChild(el("div", { class: "wb-section-title", style: "margin-top:0", text: "Your POH and documents" }));

    if (!S.user) {
      panel.appendChild(el("p", { class: "acct-note", text: "Sign in to attach your own POH or AFM PDF to this aircraft. Files are private to your account." }));
      panel.appendChild(el("button", { class: "btn", type: "button", text: "Sign in or create account", onclick: openAccount }));
      return panel;
    }

    var msg = el("p", { class: "acct-note", role: "status", text: "" });
    var list = el("div", { class: "file-list" });
    var input = el("input", { type: "file", accept: "application/pdf,.pdf", "aria-label": "Choose a PDF to upload" });

    function setMsg(t, bad) { msg.textContent = t || ""; msg.className = "acct-note" + (bad ? " warn" : ""); }

    async function load() {
      list.textContent = "Loading...";
      try {
        var r = must(await api("GET", "/api/files?aircraft=" + encodeURIComponent(key)));
        list.textContent = "";
        var files = (r.data && r.data.files) || [];
        if (!files.length) list.appendChild(el("p", { class: "acct-note", text: "No files attached to this aircraft yet." }));
        files.forEach(function (f) {
          var row = el("div", { class: "file-row" }, [
            el("span", { class: "file-name", text: f.name }),
            el("span", { class: "file-size", text: fmtSize(f.size) }),
            el("a", { class: "btn", href: "/api/files/" + f.id, target: "_blank", rel: "noopener", text: "Open" }),
            el("button", { class: "btn danger", type: "button", text: "Delete", onclick: async function () {
              if (!window.confirm("Delete " + f.name + "?")) return;
              try { must(await api("DELETE", "/api/files/" + f.id)); setMsg("Deleted."); load(); }
              catch (e) { setMsg(e instanceof TypeError ? "You are offline." : e.message, true); }
            } }),
          ]);
          list.appendChild(row);
        });
      } catch (e) {
        list.textContent = "";
        setMsg(e instanceof TypeError ? "You are offline. Files are available when you are connected." : e.message, true);
      }
    }

    input.addEventListener("change", async function () {
      var f = input.files && input.files[0];
      if (!f) return;
      if (f.size > MAX_PDF) { setMsg("That file is larger than 25 MB.", true); input.value = ""; return; }
      if (f.type && f.type !== "application/pdf") { setMsg("Only PDF files can be uploaded.", true); input.value = ""; return; }
      setMsg("Uploading...");
      try {
        must(await api("POST", "/api/files?aircraft=" + encodeURIComponent(key) + "&name=" + encodeURIComponent(f.name), undefined, f));
        setMsg("Uploaded.");
        load();
      } catch (e) {
        setMsg(e instanceof TypeError ? "You are offline." : e.message, true);
      }
      input.value = "";
    });

    panel.appendChild(list);
    panel.appendChild(el("div", { class: "meta-row" }, [input]));
    panel.appendChild(msg);
    panel.appendChild(el("p", { class: "acct-note", text: "Upload only documents you are entitled to keep. Files are private to your account, up to 25 MB each, and are never shown to other pilots." }));
    load();
    return panel;
  }

  /* -------------------------------------------------------------------- init */
  async function init() {
    var btn = document.getElementById("accountBtn");
    if (btn) btn.addEventListener("click", openAccount);

    if (meta.uid) {
      // Was signed in on this device: show that state immediately, then verify with the server.
      S.user = { id: meta.uid, email: meta.email };
      setStatus("offline");
    }
    try {
      var r = await api("GET", "/api/auth/me");
      if (r.ok) {
        S.user = r.data.user;
        meta.uid = S.user.id;
        meta.email = S.user.email;
        saveMeta();
        scanDirty();
        await sync();
      } else if (r.status === 401) {
        if (meta.uid) { S.user = null; setStatus("expired"); }
        else setStatus("signedout");
      }
    } catch (e) {
      if (S.user) setStatus("offline"); else setStatus("signedout");
    }

    window.addEventListener("online", function () { sync(); });
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "visible" && S.user && (!S.lastSync || Date.now() - S.lastSync > 20000)) sync();
    });
    setInterval(function () {
      if (S.user && document.visibilityState === "visible") sync();
    }, 5 * 60 * 1000);
  }

  window.qrhSync = { markDirty: markDirty, docsPanel: docsPanel, openAccount: openAccount, sync: sync };
  init();
})();
