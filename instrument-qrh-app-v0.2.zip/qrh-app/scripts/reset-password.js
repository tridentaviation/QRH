"use strict";
// Owner-run password reset (there is no email reset flow yet).
// Usage: DATA_DIR=/path node scripts/reset-password.js user@example.com "new password here"
const path = require("path");
const bcrypt = require("bcryptjs");
const { openDb } = require("../server/db");

const [email, password] = process.argv.slice(2);
if (!email || !password) {
  console.error('Usage: node scripts/reset-password.js <email> "<new password>"');
  process.exit(1);
}
const bytes = Buffer.byteLength(password, "utf8");
if (bytes < 10 || bytes > 72) {
  console.error("Password must be 10 to 72 bytes.");
  process.exit(1);
}
const dataDir = process.env.DATA_DIR || path.join(__dirname, "..", "data");
const db = openDb(dataDir);
const user = db.prepare("SELECT id FROM users WHERE email = ?").get(email.trim().toLowerCase());
if (!user) {
  console.error("No such user.");
  process.exit(1);
}
db.prepare("UPDATE users SET pass_hash = ? WHERE id = ?").run(bcrypt.hashSync(password, 12), user.id);
db.prepare("DELETE FROM sessions WHERE user_id = ?").run(user.id);
console.log("Password reset and all sessions signed out for", email);
