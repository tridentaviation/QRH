"use strict";
const express = require("express");

const MAX_VALUE_BYTES = 600 * 1024;
const MAX_DOCS = 500;
const MAX_TOTAL_BYTES = 20 * 1024 * 1024;
const KEY_RE = /^[^\u0000-\u001f\u007f]{1,200}$/u;

function createDocs(db, requireAuth) {
  const q = {
    all: db.prepare("SELECT key, value, version, updated_at FROM docs WHERE user_id = ?"),
    one: db.prepare("SELECT value, version, updated_at FROM docs WHERE user_id = ? AND key = ?"),
    insert: db.prepare("INSERT INTO docs (user_id, key, value, version, updated_at) VALUES (?, ?, ?, 1, ?)"),
    update: db.prepare("UPDATE docs SET value = ?, version = version + 1, updated_at = ? WHERE user_id = ? AND key = ?"),
    count: db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(LENGTH(value)), 0) AS bytes FROM docs WHERE user_id = ?"),
  };

  const put = db.transaction((userId, key, str, baseVersion, updatedAt) => {
    const cur = q.one.get(userId, key);
    if (!cur) {
      const t = q.count.get(userId);
      if (t.n >= MAX_DOCS) return { status: 400, body: { error: "Too many documents in this account." } };
      if (t.bytes + str.length > MAX_TOTAL_BYTES) return { status: 400, body: { error: "Account storage limit reached." } };
      q.insert.run(userId, key, str, updatedAt);
      return { status: 200, body: { version: 1, updatedAt } };
    }
    if (baseVersion !== cur.version) {
      return {
        status: 409,
        body: { error: "conflict", current: { value: JSON.parse(cur.value), version: cur.version, updatedAt: cur.updated_at } },
      };
    }
    const t = q.count.get(userId);
    if (t.bytes - cur.value.length + str.length > MAX_TOTAL_BYTES) {
      return { status: 400, body: { error: "Account storage limit reached." } };
    }
    q.update.run(str, updatedAt, userId, key);
    return { status: 200, body: { version: cur.version + 1, updatedAt } };
  });

  const router = express.Router();
  router.use(requireAuth);
  router.use(express.json({ limit: "700kb" }));

  router.get("/", (req, res) => {
    const docs = q.all.all(req.user.id).map((r) => ({
      key: r.key,
      value: JSON.parse(r.value),
      version: r.version,
      updatedAt: r.updated_at,
    }));
    res.json({ docs });
  });

  router.put("/", (req, res) => {
    const { key, value, baseVersion, updatedAt } = req.body || {};
    if (typeof key !== "string" || !KEY_RE.test(key)) return res.status(400).json({ error: "Invalid key." });
    if (value === undefined) return res.status(400).json({ error: "Missing value." });
    if (!Number.isInteger(baseVersion) || baseVersion < 0) return res.status(400).json({ error: "Invalid baseVersion." });
    const str = JSON.stringify(value);
    if (Buffer.byteLength(str, "utf8") > MAX_VALUE_BYTES) return res.status(413).json({ error: "Document too large." });
    const now = Date.now();
    let when = Number.isFinite(updatedAt) ? Math.floor(updatedAt) : now;
    when = Math.max(0, Math.min(when, now + 5 * 60 * 1000));
    const out = put(req.user.id, key, str, baseVersion, when);
    res.status(out.status).json(out.body);
  });

  return router;
}

module.exports = { createDocs };
