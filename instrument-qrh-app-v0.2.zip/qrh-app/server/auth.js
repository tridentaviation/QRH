"use strict";
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const express = require("express");
const { rateLimit, ipKeyGenerator } = require("express-rate-limit");

const COOKIE = "qrh_sid";
const BCRYPT_COST = 12;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function hashToken(t) {
  return crypto.createHash("sha256").update(t).digest("hex");
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  header.split(";").forEach((part) => {
    const i = part.indexOf("=");
    if (i < 0) return;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

function validateCredentials(email, password) {
  if (typeof email !== "string" || typeof password !== "string") return "Email and password are required.";
  const e = email.trim().toLowerCase();
  if (e.length > 254 || !EMAIL_RE.test(e)) return "Enter a valid email address.";
  // bcrypt only uses the first 72 bytes, so refuse longer passwords instead of silently truncating
  const bytes = Buffer.byteLength(password, "utf8");
  if (bytes < 10) return "Password must be at least 10 characters.";
  if (bytes > 72) return "Password must be 72 bytes or fewer.";
  return null;
}

function createAuth(db, opts) {
  const sessionMs = opts.sessionDays * 86400 * 1000;
  const secure = opts.secureCookie;
  const dummyHash = bcrypt.hashSync("not-a-real-password", BCRYPT_COST);

  const q = {
    userByEmail: db.prepare("SELECT id, email, pass_hash FROM users WHERE email = ?"),
    insertUser: db.prepare("INSERT INTO users (email, pass_hash, created_at) VALUES (?, ?, ?)"),
    insertSession: db.prepare("INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)"),
    sessionUser: db.prepare(
      "SELECT u.id AS id, u.email AS email FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?"
    ),
    deleteSession: db.prepare("DELETE FROM sessions WHERE token_hash = ?"),
    purgeExpired: db.prepare("DELETE FROM sessions WHERE expires_at <= ?"),
    userFiles: db.prepare("SELECT id FROM files WHERE user_id = ?"),
    deleteUser: db.prepare("DELETE FROM users WHERE id = ?"),
    userById: db.prepare("SELECT id, email, pass_hash FROM users WHERE id = ?"),
  };

  const purge = setInterval(() => q.purgeExpired.run(Date.now()), 3600 * 1000);
  purge.unref();

  function setSessionCookie(res, token) {
    res.cookie(COOKIE, token, { httpOnly: true, sameSite: "lax", secure, path: "/", maxAge: sessionMs });
  }
  function clearSessionCookie(res) {
    res.clearCookie(COOKIE, { httpOnly: true, sameSite: "lax", secure, path: "/" });
  }
  function startSession(res, userId) {
    const token = crypto.randomBytes(32).toString("base64url");
    const now = Date.now();
    q.insertSession.run(hashToken(token), userId, now, now + sessionMs);
    setSessionCookie(res, token);
  }

  // Attach req.user when the session cookie is valid.
  function loadUser(req, _res, next) {
    req.user = null;
    const token = parseCookies(req.headers.cookie)[COOKIE];
    if (token && token.length < 200) {
      const row = q.sessionUser.get(hashToken(token), Date.now());
      if (row) {
        req.user = { id: row.id, email: row.email };
        req.sessionToken = token;
      }
    }
    next();
  }

  function requireAuth(req, res, next) {
    if (!req.user) return res.status(401).json({ error: "Not signed in." });
    next();
  }

  // State-changing requests must carry a custom header. Browsers will not add it to
  // cross-site form posts, and SameSite=Lax cookies are not sent cross-site anyway.
  function requireClientHeader(req, res, next) {
    if (req.method === "GET" || req.method === "HEAD" || req.method === "OPTIONS") return next();
    if (req.get("x-qrh-client") !== "1") return res.status(403).json({ error: "Missing client header." });
    next();
  }

  const ipLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: opts.authLimitPerIp,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many attempts. Try again later." },
  });
  const emailLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: opts.authLimitPerEmail,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many attempts for this account. Try again later." },
    keyGenerator: (req) => {
      const e = req.body && typeof req.body.email === "string" ? req.body.email.trim().toLowerCase().slice(0, 254) : "";
      return "e:" + e + ":" + ipKeyGenerator(req.ip);
    },
  });

  const router = express.Router();

  router.get("/me", (req, res) => {
    if (!req.user) return res.status(401).json({ error: "Not signed in." });
    res.json({ user: req.user });
  });

  router.post("/signup", ipLimiter, emailLimiter, async (req, res) => {
    const { email, password } = req.body || {};
    const bad = validateCredentials(email, password);
    if (bad) return res.status(400).json({ error: bad });
    const e = email.trim().toLowerCase();
    if (q.userByEmail.get(e)) return res.status(409).json({ error: "An account with that email already exists." });
    const hash = await bcrypt.hash(password, BCRYPT_COST);
    let info;
    try {
      info = q.insertUser.run(e, hash, Date.now());
    } catch (err) {
      return res.status(409).json({ error: "An account with that email already exists." });
    }
    const user = { id: Number(info.lastInsertRowid), email: e };
    startSession(res, user.id);
    res.status(201).json({ user });
  });

  router.post("/login", ipLimiter, emailLimiter, async (req, res) => {
    const { email, password } = req.body || {};
    if (typeof email !== "string" || typeof password !== "string" || password.length > 200) {
      return res.status(400).json({ error: "Email and password are required." });
    }
    const row = q.userByEmail.get(email.trim().toLowerCase());
    // Compare against a dummy hash when the user is unknown so timing does not reveal which emails exist.
    const ok = await bcrypt.compare(password, row ? row.pass_hash : dummyHash);
    if (!row || !ok) return res.status(401).json({ error: "Invalid email or password." });
    startSession(res, row.id);
    res.json({ user: { id: row.id, email: row.email } });
  });

  router.post("/logout", (req, res) => {
    if (req.sessionToken) q.deleteSession.run(hashToken(req.sessionToken));
    clearSessionCookie(res);
    res.json({ ok: true });
  });

  router.post("/delete", requireAuth, ipLimiter, async (req, res) => {
    const password = req.body && req.body.password;
    if (typeof password !== "string") return res.status(400).json({ error: "Password is required." });
    const row = q.userById.get(req.user.id);
    const ok = row && (await bcrypt.compare(password, row.pass_hash));
    if (!ok) return res.status(401).json({ error: "Incorrect password." });
    const ids = q.userFiles.all(req.user.id).map((r) => r.id);
    q.deleteUser.run(req.user.id); // cascades to sessions, docs and file rows
    ids.forEach((id) => {
      fs.rm(path.join(opts.dataDir, "files", id + ".pdf"), { force: true }, () => {});
    });
    clearSessionCookie(res);
    res.json({ ok: true });
  });

  return { router, loadUser, requireAuth, requireClientHeader };
}

module.exports = { createAuth, hashToken, BCRYPT_COST };
