"use strict";
const { createApp } = require("./app");

const { app } = createApp();
const port = Number(process.env.PORT || 8000);
app.listen(port, () => {
  console.log("Instrument QRH listening on http://localhost:" + port);
});
