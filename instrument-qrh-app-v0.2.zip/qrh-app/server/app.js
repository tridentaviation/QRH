"use strict";
const express = require("express");
const helmet = require("helmet");
const path = require("path");
const { openDb } = require("./db");
const { createAuth } = require("./auth");
const { createDocs } = require("./docs");
const { createFiles } = require("./files");

function createApp(options = {}) {
  const env = process.env;
  const production = env.NODE_ENV === "production";
  const opts = {
    dataDir: options.dataDir || env.DATA_DIR || path.join(__dirname, "..", "data"),
    sessionDays: Number(options.sessionDays || env.SESSION_DAYS || 30),
    secureCookie:
      options.secureCookie !== undefined ? options.secureCookie : env.COOKIE_SECURE ? env.COOKIE_SECURE === "true" : production,
    authLimitPerIp: options.authLimitPerIp || 30,
    authLimitPerEmail: options.authLimitPerEmail || 8,
  };

  const db = openDb(opts.dataDir);
  const app = express();
  app.disable("x-powered-by");
  if (env.TRUST_PROXY) app.set("trust proxy", Number(env.TRUST_PROXY) || 1);

  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: false,
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com"],
          imgSrc: ["'self'", "data:"],
          connectSrc: ["'self'"],
          manifestSrc: ["'self'"],
          workerSrc: ["'self'"],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'none'"],
          ...(opts.secureCookie ? { upgradeInsecureRequests: [] } : {}),
        },
      },
      strictTransportSecurity: opts.secureCookie,
    })
  );

  app.get("/healthz", (_req, res) => res.json({ ok: true }));

  const auth = createAuth(db, opts);
  app.use("/api", (_req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
  });
  app.use("/api", auth.loadUser, auth.requireClientHeader);
  app.use("/api/auth", express.json({ limit: "10kb" }), auth.router);
  app.use("/api/docs", createDocs(db, auth.requireAuth));
  app.use("/api/files", createFiles(db, auth.requireAuth, opts.dataDir));
  app.use("/api", (_req, res) => res.status(404).json({ error: "Not found." }));

  app.use(
    express.static(path.join(__dirname, "..", "public"), {
      setHeaders(res, file) {
        if (/(sw\.js|manifest\.webmanifest|index\.html)$/.test(file)) res.setHeader("Cache-Control", "no-cache");
      },
    })
  );

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err && err.type === "entity.too.large") return res.status(413).json({ error: "Request too large." });
    if (err && (err.type === "entity.parse.failed" || err.type === "charset.unsupported" || err.type === "encoding.unsupported")) {
      return res.status(400).json({ error: "Bad request." });
    }
    console.error(err);
    res.status(500).json({ error: "Server error." });
  });

  return { app, db, close: () => db.close() };
}

module.exports = { createApp };
