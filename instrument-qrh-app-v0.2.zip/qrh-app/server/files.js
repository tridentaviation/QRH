"use strict";
const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const MAX_FILE_BYTES = 25 * 1024 * 1024;
const MAX_FILES = 40;
const MAX_TOTAL_BYTES = 150 * 1024 * 1024;
const ID_RE = /^[a-f0-9]{32}$/;

function cleanName(raw) {
  let n = typeof raw === "string" ? raw : "";
  n = n.replace(/[\u0000-\u001f\u007f\\/:*?"<>|]/g, "_").trim().slice(0, 120);
  if (!n) n = "POH.pdf";
  if (!/\.pdf$/i.test(n)) n += ".pdf";
  return n;
}

function createFiles(db, requireAuth, dataDir) {
  const dir = path.join(dataDir, "files");
  const q = {
    list: db.prepare("SELECT id, aircraft_key, name, size, created_at FROM files WHERE user_id = ? AND aircraft_key = ? ORDER BY created_at DESC"),
    one: db.prepare("SELECT id, name, size FROM files WHERE id = ? AND user_id = ?"),
    insert: db.prepare("INSERT INTO files (id, user_id, aircraft_key, name, size, created_at) VALUES (?, ?, ?, ?, ?, ?)"),
    del: db.prepare("DELETE FROM files WHERE id = ? AND user_id = ?"),
    totals: db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(size), 0) AS bytes FROM files WHERE user_id = ?"),
  };

  const router = express.Router();
  router.use(requireAuth);

  router.get("/", (req, res) => {
    const aircraft = typeof req.query.aircraft === "string" ? req.query.aircraft.slice(0, 200) : "";
    const files = q.list.all(req.user.id, aircraft).map((r) => ({
      id: r.id,
      aircraft: r.aircraft_key,
      name: r.name,
      size: r.size,
      createdAt: r.created_at,
    }));
    res.json({ files });
  });

  router.post("/", express.raw({ type: "application/pdf", limit: MAX_FILE_BYTES }), async (req, res) => {
    const aircraft = typeof req.query.aircraft === "string" ? req.query.aircraft.trim().slice(0, 200) : "";
    if (!aircraft) return res.status(400).json({ error: "Missing aircraft." });
    const body = req.body;
    if (!Buffer.isBuffer(body) || body.length === 0) return res.status(400).json({ error: "Send a PDF file." });
    if (body.slice(0, 5).toString("latin1") !== "%PDF-") return res.status(400).json({ error: "That file is not a PDF." });
    const t = q.totals.get(req.user.id);
    if (t.n >= MAX_FILES) return res.status(400).json({ error: "File limit reached. Delete a file first." });
    if (t.bytes + body.length > MAX_TOTAL_BYTES) return res.status(400).json({ error: "Storage limit reached. Delete a file first." });

    const id = crypto.randomBytes(16).toString("hex");
    const name = cleanName(req.query.name);
    const file = path.join(dir, id + ".pdf");
    await fs.promises.writeFile(file, body, { flag: "wx", mode: 0o600 });
    const createdAt = Date.now();
    try {
      q.insert.run(id, req.user.id, aircraft, name, body.length, createdAt);
    } catch (err) {
      await fs.promises.rm(file, { force: true });
      throw err;
    }
    res.status(201).json({ file: { id, aircraft, name, size: body.length, createdAt } });
  });

  router.get("/:id", (req, res) => {
    const id = req.params.id;
    if (!ID_RE.test(id)) return res.status(404).json({ error: "Not found." });
    const row = q.one.get(id, req.user.id);
    if (!row) return res.status(404).json({ error: "Not found." });
    const file = path.join(dir, id + ".pdf");
    if (!fs.existsSync(file)) return res.status(404).json({ error: "Not found." });
    res.removeHeader("Content-Security-Policy");
    res.set({
      "Content-Type": "application/pdf",
      "Content-Disposition": "inline; filename*=UTF-8''" + encodeURIComponent(row.name),
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, no-store",
      "Content-Length": String(row.size),
    });
    fs.createReadStream(file).pipe(res);
  });

  router.delete("/:id", (req, res) => {
    const id = req.params.id;
    if (!ID_RE.test(id)) return res.status(404).json({ error: "Not found." });
    const info = q.del.run(id, req.user.id);
    if (info.changes === 0) return res.status(404).json({ error: "Not found." });
    fs.rm(path.join(dir, id + ".pdf"), { force: true }, () => {});
    res.json({ ok: true });
  });

  return router;
}

module.exports = { createFiles };
